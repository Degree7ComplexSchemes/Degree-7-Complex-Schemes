from pathlib import Path
import json,hashlib

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent/'census'
data=json.loads((ROOT/'data/witnesses.json').read_text())
second=json.loads((ROOT/'data/type_ii/verified.json').read_text())
triangles={t['id']:t for t in data['triangulations']}

def signed_scheme(nodes):
    leaves={'+':0,'-':0};parts=[]
    for n in nodes:
        if not n['children']:leaves[n['sign']]+=1
        else:parts.append('1'+('⁺' if n['sign']=='+' else '⁻')+'⟨'+signed_scheme(n['children'])+'⟩')
    front=[str(leaves[s])+('⁺' if s=='+' else '⁻') for s in ('+','-') if leaves[s]]
    return ' ⊔ '.join(front+parts)

def real_scheme(nodes):
    leaves=sum(not n['children'] for n in nodes)
    parts=([str(leaves)] if leaves else [])+['1⟨'+real_scheme(n['children'])+'⟩' for n in nodes if n['children']]
    return ' ⊔ '.join(parts)

manifest=[]
for r in sorted(data['records'],key=lambda r:r['paper_row']):
    t=triangles[r['triangulation']]
    manifest.append({'id':f"I-{r['paper_row']:02}",'type':'I','paper_row':r['paper_row'],
        'triangulation':r['triangulation'],'mask_hex':r['mask_hex'].upper(),'points':t['points'],'triangles':t['triangles'],
        'expected_complex':r['complex_scheme'],
        'real_label':'J'+(' ⊔ '+real_scheme(r['complex_scheme']['ovals']) if r['complex_scheme']['ovals'] else ''),
        'complex_label':'J'+(' ⊔ '+signed_scheme(r['complex_scheme']['ovals']) if r['complex_scheme']['ovals'] else '')})

def order(r):
    if r['key'].startswith('U'):return (0,int(r['key'][1:]),0)
    a,b=map(int,r['key'][1:].split(','));return (1,a,b)
for n,r in enumerate(sorted(second['records'],key=order),1):
    t=triangles[r['triangulation']]
    if r['key'].startswith('U'):
        k=int(r['key'][1:]);real='J'+(' ⊔ '+str(k) if k else '')
    else:
        a,b=map(int,r['key'][1:].split(','));real='J'+(' ⊔ '+str(a) if a else '')+' ⊔ 1⟨'+str(b)+'⟩'
    manifest.append({'id':f'II-{n:03}','type':'II','index':n,'scheme_key':r['key'],
        'triangulation':r['triangulation'],'mask_hex':r['mask_hex'].upper(),'points':t['points'],'triangles':t['triangles'],
        'real_label':real,'complex_label':real+'   (II)'})
assert len(manifest)==199 and len({r['complex_label'] for r in manifest if r['type']=='I'})==93
(HERE/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print('Prepared',len(manifest),'current paper witnesses, retaining each triangulation/mask association.')
