"""Render the current 93/106 paper witnesses through the original Viro.sage."""
import os,sys,json,importlib.util,argparse,time,ast,hashlib
from pathlib import Path
from sage.all import *

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--limit',type=int);ap.add_argument('--type',choices=['I','II','all'],default='all');ap.add_argument('--reuse-through',type=int,default=0);ap.add_argument('--output-dir',type=Path);a=ap.parse_args()
    here=Path(__file__).resolve().parent
    legacy=here/'vendor/legacy_viro'
    output_dir=(a.output_dir or here/'generated').resolve()
    (output_dir/'panels').mkdir(parents=True,exist_ok=True)
    sys.path.insert(0,str(legacy/'outputs'))
    load(str(legacy/'outputs/Viro.sage'))
    load(str(legacy/'outputs/viro_symmetric_orientation.sage'))
    load(str(legacy/'outputs/SymmetricOrientationCensusBuilder.sage'))
    # Read the old cloud's options verbatim; purple arrows and the requested
    # type-II background triangulations are the only style additions.
    cloud_source=legacy/'outputs/BUILD_DEGREE7_TYPE_BUCKET_CLOUD.sage'
    cloud_ast=ast.parse(cloud_source.read_text())
    cloud_render=next(n for n in cloud_ast.body if isinstance(n,ast.FunctionDef) and n.name=='_render_image')
    cloud_branch=next(n for n in cloud_render.body if isinstance(n,ast.If))
    def cloud_options(branch):
        assignment=next(n for n in branch if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='options' for t in n.targets))
        return ast.literal_eval(assignment.value)
    old_options={'I':cloud_options(cloud_branch.body),'II':cloud_options(cloud_branch.orelse)}
    cloud_hash=hashlib.sha256(cloud_source.read_bytes()).hexdigest()
    reader=here.parent/'census/readers/complex_scheme.py'
    spec=importlib.util.spec_from_file_location('verified_reader',reader);cs=importlib.util.module_from_spec(spec);spec.loader.exec_module(cs)
    all_records=json.loads((here/'manifest.json').read_text());records=all_records;receipts=[];started=time.monotonic()
    if a.type!='all':records=[r for r in records if r['type']==a.type]
    if a.limit:records=records[:a.limit]+([r for r in all_records if r['type']=='II'][:1] if a.type=='all' else [])
    for record_number,r in enumerate(records,1):
        triangles=[tuple(map(tuple,t)) for t in r['triangles']];points=list(map(tuple,r['points']))
        mask=int(r['mask_hex'],16);sig={p:(mask>>i)&1 for i,p in enumerate(points)};signs={p:1-2*s for p,s in sig.items()}
        viro=ViroComplex(ViroPolynomial(signdict=signs),triangulation=triangles,color='#202020')
        ori=SymmetricOrientation(viro=viro,triangulation=triangles,signdict=signs)
        is_type_i=bool(ori.IsTypeI());assert is_type_i==(r['type']=='I'),r['id']
        if is_type_i:
            copies,arcs=cs.build_chart(triangles,sig,7);tree=cs.read_chart(copies,arcs,7)
            def canon(nodes):return tuple(sorted((n['sign'],canon(n['children'])) for n in nodes))
            def visit(v):return tuple(sorted((tree['signs'][w],visit(w)) for w in tree['children'][v]))
            assert visit(tree['root'])==canon(r['expected_complex']['ovals']),r['id']
            assert cs.rokhlin_residual(tree,7)==0
        else:
            try:cs.symmetric_orientation(triangles,sig)
            except cs.NotTypeI:pass
            else:raise ValueError('Independent reader says type I: '+r['id'])
            copies,arcs=cs.build_chart(triangles,sig,7,orientations=[0]*49);tree=cs.read_chart(copies,arcs,7,signed=False)
            first=tree['children'].get(tree['root'],[]);containers=[v for v in first if tree['children'].get(v)]
            key='U'+str(len(first)) if not containers else 'N%d,%d'%(len(first)-1,len(tree['children'][containers[0]]))
            assert key==r['scheme_key'],(r['id'],key)
        q=ori.QuotientRealPartGraph();assert q.get('supported'),r['id']
        infos=_cs_rp2_component_infos_from_qgraph(q,degree=ori.degree)
        js=[int(i['index']) for i in infos if i.get('one_sided')];assert len(js)==1
        builder=SymmetricOrientationCensusBuilder(degree=7,triangulation=triangles)
        # The old key uses _so_tuple, which truncates half-integral midpoints.
        # Retain exact coordinates; this changes no drawing/style parameter.
        builder._segment_key=lambda tail,head:tuple(sorted((tuple(tail),tuple(head))))
        options=dict(old_options[r['type']])
        if is_type_i:options['arrow_color']='#8000cc'
        assert {k for k in options if options[k]!=old_options[r['type']][k]}==({'arrow_color'} if is_type_i else set())
        cloud_row={'raw_phase_key':''.join(str(sig[tuple(p)]) for p in builder.support)}
        assert _socb_signdict_from_bits(builder._bits_for_phase_key(cloud_row['raw_phase_key']),builder.support)==signs
        plot=builder._plot_for_row(cloud_row,image_plot_type='viro_orientation' if is_type_i else 'viro',image_options=options)
        background_options=None
        if not is_type_i:
            background_options=dict(mirrored=True,color=old_options['I']['skeleton_color'],
                thickness=old_options['I']['skeleton_thickness'],show_boundary=True,
                boundary_color=old_options['I']['skeleton_boundary_color'],
                boundary_thickness=old_options['I']['skeleton_boundary_thickness'])
            expected_edges={tuple(sorted(((sx*p[0],sy*p[1]),(sx*t[(i+1)%3][0],sy*t[(i+1)%3][1]))))
                for t in triangles for i,p in enumerate(t) for sx in (-1,1) for sy in (-1,1)}
            actual_edges={tuple(sorted(map(tuple,e))) for e in ori.TriangulationSkeletonEdges(mirrored=True)}
            assert actual_edges==expected_edges,(r['id'],'background triangulation mismatch')
            plot=ori.PlotTriangulationSkeleton(**background_options)+plot
        expected_j={tuple(sorted(tuple(float(c) for c in p) for p in e['segment'])) for e in q['components'][js[0]]['edges']}
        cloud_j_keys=builder._one_sided_component_segment_keys(signs)
        actual_j={tuple(sorted(tuple(float(c) for c in p) for p in e['segment'])) for component in q['components'] for e in component['edges'] if builder._segment_key(*e['segment']) in cloud_j_keys}
        assert actual_j==expected_j,(r['id'],'cloud J mismatch',len(actual_j),len(expected_j),list(actual_j-expected_j)[:3],list(expected_j-actual_j)[:3])
        segments=[]
        for n,component in enumerate(q['components']):
            for edge in component['edges']:
                segments.append(tuple(sorted(tuple(float(c) for c in p) for p in edge['segment'])))
        # Confirm that the plotted Viro segments are exactly the independent reader's chart.
        reference={tuple(sorted(tuple(float(c) for c in p) for p in arc[:2])) for arc in arcs.values()}
        assert set(segments)==reference,(r['id'],'chart segment mismatch',len(set(segments)),len(reference),list(set(segments)-reference)[:3],list(reference-set(segments))[:3])
        if not is_type_i:
            dual=DualTropicalPatchwork(triangulation=triangles,signdict=signs)
            drawn={tuple(sorted(tuple(float(c) for c in p) for p in cell['segment'])) for cell in dual.RealPatchworkSegments(mirrored=True)}
            assert drawn==reference,(r['id'],'old cloud geometry mismatch')
        if is_type_i:
            def direction_table(edges):
                table={}
                for arc in edges:
                    tail,head=(tuple(float(c) for c in p) for p in arc[:2])
                    table[tuple(sorted((tail,head)))]=1 if tail<head else -1
                return table
            native=direction_table(ori.OrientedCurveEdges(orientation=0,mirrored=True))
            independent=direction_table(arcs.values())
            assert set(native)==set(independent),r['id']
            multipliers={native[k]*independent[k] for k in native}
            assert len(multipliers)==1,(r['id'],'orientation directions disagree',multipliers)
        out=output_dir/'panels'/r['id']
        opts=dict(axes=False,figsize=7.2)
        if record_number>a.reuse_through:
            plot.save(str(out)+'.pdf',**opts)
            plot.save(str(out)+'.png',dpi=210,**opts)
        else:
            assert out.with_suffix('.pdf').exists() and out.with_suffix('.png').exists()
        receipts.append({'id':r['id'],'type':r['type'],'triangulation':r['triangulation'],'mask_hex':r['mask_hex'],
            'type_agreement':True,'scheme_agreement':True,'chart_segment_agreement':True,'orientation_agreement':True if is_type_i else None,
            'component_count':int(q['component_count']),'J_components':len(js),'arrow_color':'#8000cc' if is_type_i else None,
            'cloud_renderer':'SymmetricOrientationCensusBuilder._plot_for_row','cloud_options':options,
            'cloud_source_sha256':cloud_hash,'cloud_style_only_change':'arrow_color' if is_type_i else None,
            'background_triangulation_options':background_options,'background_triangulation_agreement':True if not is_type_i else None,
            'J_segment_agreement':True,'J_coordinate_keys':'exact midpoint coordinates','J_color':options['j_component_color']})
        print(json.dumps({'completed':len(receipts),'id':r['id'],'seconds':float(round(time.monotonic()-started,1))}),flush=True)
    if a.type!='all' and not a.limit:
        previous={r['id']:r for r in json.loads((here/'render_audit.json').read_text())}
        previous.update({r['id']:r for r in receipts})
        receipts=[previous[r['id']] for r in all_records]
    (output_dir/('smoke_audit.json' if a.limit else 'render_audit.json')).write_text(json.dumps(receipts,indent=2)+'\n')

if __name__=='__main__':main()
