"""Assemble Viro.sage vector plots into four-by-four preview plates."""
from pathlib import Path
import argparse,io,json,math,os
from pypdf import PdfReader,PdfWriter,Transformation
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor
from reportlab.lib.pagesizes import A3

HERE=Path(__file__).resolve().parent
OUT=HERE/'generated/pdf'
PANELS=HERE/'panels'
# Preserve the published Arial/Segoe layout when those fonts are available.
# Matplotlib's bundled DejaVu fonts provide a portable Unicode fallback.
windows_fonts=Path(os.environ.get('WINDIR','C:/Windows'))/'Fonts'
if all((windows_fonts/n).exists() for n in ('arial.ttf','arialbd.ttf','seguisym.ttf')):
    fonts=[windows_fonts/n for n in ('arial.ttf','arialbd.ttf','seguisym.ttf')]
else:
    import matplotlib
    bundled=Path(matplotlib.get_data_path())/'fonts/ttf'
    fonts=[bundled/n for n in ('DejaVuSans.ttf','DejaVuSans-Bold.ttf','DejaVuSans.ttf')]
for name,path in zip(('PlateSans','PlateBold','PlateSymbols'),fonts):
    pdfmetrics.registerFont(TTFont(name,str(path)))

def fit(c,text,x,y,width,size=9.3,font='PlateSymbols',color='#202020'):
    actual=min(size,size*width/max(width,pdfmetrics.stringWidth(text,font,size)))
    assert actual>=6.9,(text,actual)
    c.setFillColor(HexColor(color));c.setFont(font,actual);c.drawString(x,y,text)
    return actual

def build(kind,records,path):
    writer=PdfWriter();mapping=[];W,H=A3;M=25;TOP=H-69;BOTTOM=31
    CW=(W-2*M)/4;CH=(TOP-BOTTOM)/4
    for start in range(0,len(records),16):
        group=records[start:start+16];npage=start//16+1;pages=math.ceil(len(records)/16)
        stream=io.BytesIO();c=canvas.Canvas(stream,pagesize=(W,H))
        c.setTitle('Degree 7 '+('dividing' if kind=='I' else 'nondividing')+' T-curve plates')
        c.setFillColor(HexColor('#171717'));c.setFont('PlateBold',19)
        c.drawString(M,H-33,'Degree 7 - '+('dividing T-curves' if kind=='I' else 'nondividing T-curves'))
        c.setFont('PlateSans',9);c.setFillColor(HexColor('#5c6267'))
        c.drawString(M,H-49,f'{len(records)} paper witnesses | plate {npage} of {pages} | Viro.sage')
        c.drawRightString(W-M,H-49,group[0]['id']+' - '+group[-1]['id'])
        positions=[]
        for row in range(4):
            chunk=group[row*4:(row+1)*4]
            offset=(4-len(chunk))*CW/2
            for col,r in enumerate(chunk):
                x=M+offset+col*CW;y=TOP-(row+1)*CH
                title=f"{r['id']}  |  {r['triangulation']}  |  {r['mask_hex']}"
                fit(c,title,x+3,y+CH-11,CW-6,8.4,'PlateBold','#30363b')
                plot_size=min(CW-9,CH-47)
                px=x+(CW-plot_size)/2;py=y+CH-17-plot_size
                positions.append((r,px,py,plot_size))
                fit(c,'Real: '+r['real_label'],x+3,py-11,CW-6,9.3)
                if kind=='I':fit(c,'Complex: '+r['complex_label'],x+3,py-25,CW-6,9.3)
                else:fit(c,'Type II',x+3,py-25,CW-6,8.7,'PlateSans','#60676d')
                mapping.append({'id':r['id'],'type':kind,'plate':npage,'row':row+1,'column':col+1})
        c.setFillColor(HexColor('#646b70'));c.setFont('PlateSans',8)
        footer='Green: J. Purple arrows: complex orientation. Original visual-cloud style.' if kind=='I' else 'Gray: triangulation. Green: J. Type II: no complex-orientation arrows. Original visual-cloud style.'
        c.drawString(M,18,footer);c.drawRightString(W-M,18,f'{npage} / {pages}')
        c.save();page=PdfReader(io.BytesIO(stream.getvalue())).pages[0]
        for r,x,y,size in positions:
            panel=PdfReader(PANELS/(r['id']+'.pdf')).pages[0]
            bx=float(panel.mediabox.left);by=float(panel.mediabox.bottom);pw=float(panel.mediabox.width);ph=float(panel.mediabox.height)
            scale=min(size/pw,size/ph)
            tx=x+(size-pw*scale)/2-bx*scale;ty=y+(size-ph*scale)/2-by*scale
            page.merge_transformed_page(panel,Transformation().scale(scale).translate(tx,ty),over=True)
        writer.add_page(page);writer.pages[-1].compress_content_streams()
    writer.add_metadata({'/Title':'Degree 7 '+('dividing' if kind=='I' else 'nondividing')+' T-curves','/Author':'Brennan Williams','/Subject':'Preview plates from the exact 93/106 paper witness census'})
    with path.open('wb') as f:writer.write(f)
    return mapping

def main():
    global OUT,PANELS
    ap=argparse.ArgumentParser();ap.add_argument('--sample',action='store_true');ap.add_argument('--type',choices=['I','II','all'],default='all');ap.add_argument('--panel-dir',type=Path);ap.add_argument('--output-dir',type=Path);a=ap.parse_args()
    OUT=(a.output_dir or OUT).resolve();OUT.mkdir(parents=True,exist_ok=True)
    PANELS=(a.panel_dir or PANELS).resolve()
    records=json.loads((HERE/'manifest.json').read_text(encoding='utf-8'));mapping=[]
    if not a.sample:
        audit=json.loads((HERE/'render_audit.json').read_text());assert len(audit)==199
        assert all(r['type_agreement'] and r['scheme_agreement'] and r['chart_segment_agreement'] for r in audit)
        assert all(r['orientation_agreement'] for r in audit if r['type']=='I')
    for kind in ('I','II'):
        if a.type!='all' and kind!=a.type:continue
        rows=[r for r in records if r['type']==kind]
        if a.sample:rows=rows[:2] if kind=='I' else rows[:1]
        path=OUT/f'layout-sample-{kind}.pdf' if a.sample else OUT/('degree7-'+('93-dividing' if kind=='I' else '106-nondividing')+'-T-curve-plates-preview.pdf')
        mapping+=build(kind,rows,path);print(path)
    if not a.sample:
        if a.type!='all':mapping+=[r for r in json.loads((HERE/'plate_index.json').read_text()) if r['type']!=a.type]
        (OUT/'plate_index.json').write_text(json.dumps(sorted(mapping,key=lambda r:r['id']),indent=2)+'\n')

if __name__=='__main__':main()
