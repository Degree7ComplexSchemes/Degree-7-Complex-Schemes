# Final T-curve plates with triangulations

The `pdf/` directory contains the two approved plate sets: 93 dividing
curves on six pages and 106 nondividing curves on seven pages. Both include
the exact background triangulations. Dividing curves use the old visual-cloud
arrow markers in purple and J in green; labels give real and complex schemes.
Nondividing curves have real-scheme labels and no orientation arrows.

## Contents and verification

- `panels/`: all 199 individual vector PDF panels used to assemble these pages.
- `manifest.json`: exact triangulations, points, census masks, and plot labels.
- `plate_index.json`: witness-to-page/row/column index.
- `render_audit.json`: type, scheme, chart, J, orientation, and background checks.
- `PROVENANCE.json`: source hashes, package versions, fonts, and final PDF hashes.
- `vendor/legacy_viro/outputs/`: unchanged snapshots of the original Viro and
  cloud sources, plus the symmetric-orientation detector dependency.

Masks use the census convention: bit k is point k (least-significant bit is
point 0), which differs from the Section 10 family inventory convention.
The J selector preserves half-integral midpoint coordinates instead of
truncating them to integers; no drawing-style default is changed by that fix.

## Reassemble the supplied vector panels

Run from the repository root, with Python 3.10 or later:

```text
python -m pip install -r plates/requirements.txt
python -B plates/build_plates.py
```

Outputs go to `plates/generated/pdf/`; the published PDFs are preserved.
On Windows with Arial and Segoe UI Symbol installed, the original fonts are
used. Other systems use Matplotlib's bundled DejaVu fonts. Such regenerated
labels can look slightly different. PDF bytes can also differ with metadata
and library versions; the published file hashes identify the delivered PDFs.

## Regenerate the geometry with SageMath

In an environment containing SageMath (including its NumPy/Matplotlib stack):

```text
sage -python plates/render_sage.py
```

This writes fresh individual PDFs, PNGs, and a check report to
`plates/generated/`. It uses only the included source snapshots and exact
census reader; no local Desktop path or download is needed. To smoke-check
one of each type, add `--limit 1`. To render just one type, add `--type I`
or `--type II`. To assemble newly rendered panels:

```text
python -B plates/build_plates.py --panel-dir plates/generated/panels
```

Every witness is checked against the exact census. Each type I orientation
is compared with the independent reader up to one global reversal; every
type II background edge is compared with the input triangulation. The main
`reproduce.py all` calculation remains independent of these optional graphics
dependencies. Source snapshots retain their original notices; no new license
is imposed here. Temporary previews and machine-specific caches are omitted.
