"""Draw the manuscript's entry-2 representative from its exact Artin word.

TikZ only: no plotting constructor, external image service, or TeX runtime.
Positive sigma_i has the strand beginning at lower position i overcrossing.
"""
from pathlib import Path
import argparse,importlib.util

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('braid_algebra',ROOT/'obstructions/entry2/scripts/audit_table19_entry2_cover.py')
alg=importlib.util.module_from_spec(spec);spec.loader.exec_module(alg)

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
    word=alg.pencil_braid([3,4,3,2,2,2,2,2]);n=len(word);physical=list(range(1,8))
    rows=[r'\begin{tikzpicture}[x=8pt,y=15pt,line cap=round,line join=round,>=Stealth]',
          r'\tikzset{positivehalf/.style={line width=1.15pt},negativehalf/.style={line width=0.5pt}}']
    def stroke(label):return 'positivehalf' if label==3 else 'negativehalf'
    for k,g in enumerate(word):
        i=abs(g)
        for pos,label in enumerate(physical,1):
            if pos not in (i,i+1):rows.append(r'\draw[%s] (%s,%s)--(%s,%s);'%(stroke(label),k,pos,k+1,pos))
        over=i if g>0 else i+1;under=i+1 if g>0 else i
        dest={i:i+1,i+1:i}
        for pos in (under,over):
            if pos==over:rows.append(r'\draw[white,line width=3.1pt] (%s,%s)--(%s,%s);'%(k,pos,k+1,dest[pos]))
            rows.append(r'\draw[%s] (%s,%s)--(%s,%s);'%(stroke(physical[pos-1]),k,pos,k+1,dest[pos]))
        physical[i-1],physical[i]=physical[i],physical[i-1]
    assert physical[2]==3 and sorted(physical)==list(range(1,8))
    labels=[r'v',r'O',r"v_0''",r"v_0'",r'J',r'O',r'v']
    for pos in range(1,8):
        label=physical[pos-1];r=(8-pos)*0.6
        # The marked strand is fixed by the closure permutation.
        assert (pos==3)==(label==3)
        rows.append(r'\draw[%s,rounded corners=3pt] (%s,%s)--(%s,%s)--(%s,%s)--(%s,%s)--(%s,%s)--(0,%s);'%
            (stroke(label),n,pos,n+r,pos,n+r,7+r,-r,7+r,-r,pos,pos))
        y=7+r
        direction='<-' if label==3 else '->'
        rows.append(r'\draw[%s,%s] (%s,%s)--(%s,%s);'%(stroke(label),direction,n*0.48,y,n*0.55,y))
        rows.append(r'\node[anchor=east,font=\scriptsize] at (-0.1,%s) {$%s$};'%(pos,labels[pos-1]))
        direction='->' if pos==3 else '<-'
        rows.append(r'\draw[%s,%s] (-1.2,%s)--(-0.2,%s);'%(stroke(pos),direction,pos,pos))
    cut=n-21
    rows += [r'\draw[dashed,gray] (%s,0.6)--(%s,7.4);'%(cut,cut),
        r'\node[below,font=\small] at (%s,0.4) {$b_{\mathbb R}$};'%(cut/2),
        r'\node[below,font=\small] at (%s,0.4) {$\Delta_7$};'%((cut+n)/2),
        r'\node[below,font=\scriptsize,align=center] at (%s,-0.25) {thick: $L^+$; thin: $L^-$\\arrows: complex orientations};'%(n/2),
        r'\end{tikzpicture}']
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text('\n'.join(rows)+'\n',encoding='utf-8')
    print('Wrote exact',len(word),'crossing representative; marked strand 3 closes alone.')

if __name__=='__main__':main()
