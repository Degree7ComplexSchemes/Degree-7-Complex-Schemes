from pathlib import Path
from collections import defaultdict
from fractions import Fraction as Q
from itertools import combinations
import sys, json, time, hashlib

ROOT=Path(__file__).resolve().parents[1]
CERT=ROOT/'vendor/septic_certificate_v2/research'
sys.path.insert(0,str(CERT))
import septic_three_obligations_v1 as audit
from septic_verify_joint_nest_chord_v1 import joint
from septic_explicit_nonsingularity_v1 import audit_height

# Expose the polygonal region calculation already inspected in the replay.
source=(CERT/'septic_three_obligations_v1.py').read_text()
part=source[source.index('def sphere_geometry('):source.index('\ndef parity(')]
cut=part.index('    check(actual_scheme == scheme,')
part=part[:cut]+'''    return {'scheme':actual_scheme, 'parent':parent, 'children':children,
        'root':root, 'containers':containers, 'signs':signs, 'preferred':preferred,
        'vertices':{v:(rp(faces.find(fs[0])),sheet.find(fs[0])) for v,fs in vertex_faces.items()}}
'''
namespace=dict(audit.__dict__)
exec(compile(part,'<polygonal region reconstruction>','exec'),namespace)
regions=namespace['sphere_geometry']

def slopes(hd,points):
    heights=dict(zip(points,hd['integer_heights']))
    incident=defaultdict(list)
    for tri in hd['triangles']:
        p,q,r=map(tuple,tri)
        dx,dy=q[0]-p[0],q[1]-p[1]
        ex,ey=r[0]-p[0],r[1]-p[1]
        determinant=dx*ey-ex*dy
        assert abs(determinant)==1
        dh,eh=heights[q]-heights[p],heights[r]-heights[p]
        a=Q(dh*ey-eh*dy,determinant)
        b=Q(dx*eh-ex*dh,determinant)
        for v in (p,q,r):incident[v].append((a,b))
    dual={}
    for (i,j),planes in incident.items():
        k=len(planes)
        alpha=-sum(a for a,b in planes)/k+(i==0)-(i+j==7)
        beta=-sum(b for a,b in planes)/k+(j==0)-(i+j==7)
        gap=min(heights[m]-heights[i,j]+alpha*(m[0]-i)+beta*(m[1]-j) for m in points if m!=(i,j))
        assert gap>0
        dual[i,j]=(alpha,beta,gap)
    return dual

def reconstructed_model(w,typ,scheme,dual):
    geometry=regions(w,None,typ,scheme)
    assert geometry['scheme']==scheme
    containers=geometry['containers']
    if scheme[0]!='nest':return None
    if len(containers)!=1:return None
    container=containers[0]
    inner=set(geometry['children'][container])
    outer=set(geometry['children'][geometry['root']])-{container}
    centers={}
    for region in geometry['parent']:
        if region==geometry['root']:continue
        vertex=min(v for v,(r,sheet) in geometry['vertices'].items() if r==region and v[2]>=0)
        x,y,z=vertex;i,j=abs(x),abs(y)
        assert i+j+abs(z)==7
        sx,sy=(-1 if x<0 else 1),(-1 if y<0 else 1)
        ell=1 if geometry['vertices'][vertex][1]==geometry['preferred'] else -1
        alpha,beta,gap=dual[i,j]
        centers[str(region)]={'vertex':[i,j],'quadrant':[sx,sy],'lift_sign':ell,
            'amplitudes':['1','1'],'dominance_gap':str(gap),
            'vector':[[str(ell*sx),str(alpha)],[str(ell*sy),str(beta)],[str(ell),'0']]}
    colors={str(r):('i' if r in inner else 'o')+(geometry['signs'][r] if typ=='I' else '') for r in inner|outer}
    return {'centers':centers,'colors':colors,'inner_regions':sorted(inner),'outer_regions':sorted(outer)}

def main():
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
    if not __debug__:raise SystemExit('Do not use Python -O')
    if args.output.exists():raise SystemExit('Output already exists; choose a fresh output path')
    args.output.parent.mkdir(parents=True,exist_ok=True)
    start=time.monotonic()
    bank=json.loads((CERT/'septic_joint_lower_bound_g07_families.json').read_text())
    receipt=json.loads((CERT/'delivery_fresh_joint_audit.json').read_text())
    old={r['id']:audit.from_word(r['raw_joint_word']) for r in receipt['raw_joint_relations']}
    points=list(map(tuple,bank['points']))
    duals={key:slopes(hd,points) for key,hd in bank['height_data'].items()}
    # The lower facets are recovered from the height vector alone.
    for key,hd in bank['height_data'].items():audit_height(points,hd)
    groups=defaultdict(list);stats={'nodes':0};totals=defaultdict(int)
    for f in bank['families']:
        hd=bank['height_data'][f['height_data']]
        w={'triangles':hd['triangles'],'phase_mask':f['phase_mask'],
           'heights':[[p,str(h)] for p,h in zip(points,hd['integer_heights'])]}
        scheme=f['complex_scheme'] if f['type']=='I' else f['real_scheme']
        model=reconstructed_model(w,f['type'],scheme,duals[f['height_data']]) if f['real_scheme'][0]=='nest' else None
        audit.sphere_geometry(w,model,f['type'],scheme)
        if model is not None:
            base,relation,ar,cr=joint(model)
            assert audit.isomorphic(relation,old[f['id']],stats) is not None,f['id']
            totals['point_models']+=1;totals['triples']+=ar['triples'];totals['AB_conics']+=ar['conics'];totals['C_conics']+=len(cr)
        else:relation=None;totals['coarse_only']+=1
        groups[audit.dump([f['type'],scheme])].append((f['id'],relation))
        if f['id']%100==0:print(json.dumps({'families':f['id'],'seconds':round(time.monotonic()-start,1)}),flush=True)
    pairs=0
    for group in groups.values():
        for (i,a),(j,b) in combinations(group,2):
            assert a is not None and b is not None
            assert audit.isomorphic(a,b,stats) is None,(i,j)
            pairs+=1
    result={'all_pass':True,'families':len(bank['families']),'height_vectors':len(duals),'groups':len(groups),
        'pairs':pairs,'collisions':0,**totals,'seconds':round(time.monotonic()-start,2),
        'method':'Marked points reconstructed from incident lower-face gradients and support-boundary normals, amplitudes one; coherent sheets and regions reconstructed from signed triangulations. Every joint relation matches the original and all within-group pairs are nonisomorphic.'}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__':main()
