"""Export the finite-bank and marked-point certificates cited by the paper.

Python >=3.10, standard library only. These checks do not replace the
geometric patchworking and isotopy arguments in the manuscript.
"""
from pathlib import Path
import argparse,csv,hashlib,json,sys,time
from collections import Counter

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import reproduce
sys.path.insert(0,str(Path(__file__).resolve().parent))
import replay_paper_points as pp

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output-dir',type=Path,required=True)
    args=ap.parse_args()
    if not __debug__:raise SystemExit('Do not use Python -O')
    out=args.output_dir.resolve()
    if out.exists():raise SystemExit('Choose a new output directory')
    reproduce.prepare();out.mkdir(parents=True)
    bank=json.loads((pp.CERT/'septic_joint_lower_bound_g07_families.json').read_text())
    inventory=json.loads((ROOT/'data/construction_inventory.json').read_text())
    assert len(bank['families'])==len(inventory['families'])==1430
    gamma=lambda f:json.dumps([f['type'],f['complex_scheme'] if f['type']=='I' else f['real_scheme']],separators=(',',':'))
    counts=Counter(gamma(f) for f in bank['families'])
    points=list(map(tuple,bank['points']))
    duals={key:pp.slopes(hd,points) for key,hd in bank['height_data'].items()}
    coarse=[];marked=0;point_count=0;start=time.monotonic()
    csv_path=out/'marked_points.csv'
    fields=['family_id','klein_type','region','role','oval_sign','vertex_x','vertex_y','vertex_z',
            'lift_sign','alpha','beta','dominance_gap']
    with csv_path.open('w',encoding='utf-8',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
        for f in bank['families']:
            hd=bank['height_data'][f['height_data']]
            w={'triangles':hd['triangles'],'phase_mask':f['phase_mask'],
               'heights':[[p,str(h)] for p,h in zip(points,hd['integer_heights'])]}
            scheme=f['complex_scheme'] if f['type']=='I' else f['real_scheme']
            model=pp.reconstructed_model(w,f['type'],scheme,duals[f['height_data']]) if f['real_scheme'][0]=='nest' else None
            pp.audit.sphere_geometry(w,model,f['type'],scheme)
            if model is None:
                assert counts[gamma(f)]==1
                coarse.append({'family_id':f['id'],'klein_type':f['type'],
                    'real_scheme':f['real_scheme'],'complex_scheme':f.get('complex_scheme'),
                    'gamma_multiplicity_in_full_bank':counts[gamma(f)]})
            else:
                marked+=1
                for region,color in sorted(model['colors'].items(),key=lambda item:int(item[0])):
                    center=model['centers'][region];x,y=center['vertex'];sx,sy=center['quadrant']
                    writer.writerow(dict(zip(fields,[f['id'],f['type'],region,
                        'inner' if color[0]=='i' else 'exterior',color[1:] or '',sx*x,sy*y,7-x-y,
                        center['lift_sign'],center['vector'][0][1],center['vector'][1][1],center['dominance_gap']])))
                    point_count+=1
            if f['id']%200==0:print(json.dumps({'families':f['id'],'seconds':round(time.monotonic()-start,1)}),flush=True)
    assert marked==1409 and len(coarse)==21
    assert Counter(r['real_scheme'][0] for r in coarse)=={'unnested':20,'deep':1},Counter(r['real_scheme'][0] for r in coarse)
    (out/'coarse_only.json').write_text(json.dumps(coarse,indent=2)+'\n',encoding='utf-8')
    report={'all_pass':True,'families':1430,'groups':len(counts),'marked_families':marked,
        'marked_points':point_count,'coarse_only':len(coarse),'all_coarse_gamma_multiplicities':1,
        'method':'Signed regions, signed lattice vertices, coherent sheets and strict dominance gaps recomputed from the input triangulations and heights.',
        'scope':'Finite-bank correspondence only; the relative-isotopy argument is mathematical, not certified by this file.',
        'sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (csv_path,out/'coarse_only.json')}}
    (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2),flush=True)

if __name__=='__main__':main()
