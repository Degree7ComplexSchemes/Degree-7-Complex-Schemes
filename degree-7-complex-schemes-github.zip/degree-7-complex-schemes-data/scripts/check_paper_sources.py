"""Check manuscript/file bindings without compiling TeX or proving geometry."""
from pathlib import Path
import argparse,csv,json,re

ROOT=Path(__file__).resolve().parents[1]

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--paper-dir',type=Path,default=ROOT/'paper');args=ap.parse_args()
    paper=args.paper_dir.resolve();main=(paper/'main.tex').read_text(encoding='utf-8')
    tex_files=[paper/'main.tex',paper/'reproducibility.tex',paper/'tables/excluded-candidates.tex',paper/'figures/entry2-braid.tex']
    text='\n'.join(p.read_text(encoding='utf-8') for p in tex_files)
    command=lambda name:re.escape('\\'+name)
    for name in re.findall(command('RepoFile')+r'\{([^}]+)\}',text):
        # This is the documented generated-output directory, not a shipped input.
        if name=='results/':continue
        assert (ROOT/name).exists() or (ROOT/(name+'.gz')).exists(),name
    labels=set(re.findall(command('label')+r'(?:\[[^]]*\])?\{([^}]+)\}',text))
    keys=set(re.findall(command('bibitem')+r'\{([^}]+)\}',text))
    stripped=re.sub(r'(?<!\\)%[^\n]*','',text)
    for name in ('ref','eqref','cref','Cref'):
        for group in re.findall(command(name)+r'\*?\{([^}]+)\}',stripped):
            for label in group.replace('\n','').split(','):assert label.strip() in labels,(name,label)
    for group in re.findall(command('cite')+r'(?:\[[^]]*\])?\{([^}]+)\}',stripped):
        assert all(k.strip() in keys for k in group.split(',')),group
    assert 'https://github.com/Degree7ComplexSchemes/Degree-7-Complex-Schemes' in main
    assert '\\PotentialGap' not in main and 'Original figure file' not in main
    assert '\\marginpar{' in main and '\\begin{landscape}' not in main
    assert not any('p' in opt for opt in re.findall(command('begin')+r'\{figure\}\[([^]]*)\]',main))
    assert main.count('\\CompactDiagram{%')==7
    questions=json.loads((ROOT/'docs/referee-queries.json').read_text())['queries']
    for item in questions:
        assert '\\RefereeQuery{'+item['id']+'}{'+item['margin_question']+'}' in main,item['id']
    assert len(questions)==9
    census=json.loads((ROOT/'census/data/witnesses.json').read_text())
    for r in census['records']:
        pattern=r'(?m)^'+str(r['paper_row'])+r'\s*&.*?&\s*'+re.escape(r['triangulation'])+r'\s*&\s*'+command('texttt')+r'\{'+r['mask_hex'].lower()+r'\}'
        assert re.search(pattern,main),('Census row mismatch',r['paper_row'])
    with (ROOT/'data/excluded_candidates.csv').open(encoding='utf-8',newline='') as f:rows=list(csv.DictReader(f))
    assert [int(r['paper_row']) for r in rows]==list(range(1,168))
    longtable=(paper/'tables/excluded-candidates.tex').read_text(encoding='utf-8')
    for r in rows:
        n=int(r['paper_row']);real=r['real_scheme_tex'];complex_scheme=r['complex_scheme_tex']
        if n==166:complex_scheme=complex_scheme.replace('\\textcolor{red}','\\textcolor{undeterminedviolet}')
        assert real in longtable and complex_scheme in longtable,n
    assert (paper/'figures/entry17-braid.png').is_file()
    print('PASS: file locators, labels/citations, 93 census bindings, 167 table entries, nine margin queries and seven compact figures.')

if __name__=='__main__':main()
