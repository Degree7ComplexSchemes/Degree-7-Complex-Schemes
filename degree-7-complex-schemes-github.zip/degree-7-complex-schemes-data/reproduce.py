"""Portable entry point. Python >=3.10, standard library only."""
from pathlib import Path
import argparse,csv,gzip,hashlib,json,subprocess,sys,time

ROOT=Path(__file__).resolve().parent
CERT=ROOT/'vendor/septic_certificate_v2'

def require(ok,message):
    if not ok:raise ValueError(message)

def compressed_files():
    return json.loads((ROOT/'COMPRESSED_FILES.json').read_text())

def original_bytes(relative):
    p=ROOT/relative
    mapping=compressed_files()
    if relative in mapping:
        return gzip.decompress((ROOT/mapping[relative]).read_bytes())
    return p.read_bytes()

def validate():
    manifest=json.loads((ROOT/'MANIFEST.sha256.json').read_text())
    for name,expected in manifest.items():
        require(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected,'Release hash mismatch: '+name)
    original=json.loads((CERT/'INPUT_SHA256.json').read_text())
    for name,expected in original.items():
        raw=original_bytes('vendor/septic_certificate_v2/'+name)
        require(hashlib.sha256(raw).hexdigest()==expected,'Original certificate hash mismatch: '+name)
    inventory=json.loads((ROOT/'data/construction_inventory.json').read_text())
    bank=json.loads(original_bytes('vendor/septic_certificate_v2/research/septic_joint_lower_bound_g07_families.json'))
    require(len(inventory['families'])==1430 and len(inventory['height_vectors'])==103,'Inventory sizes')
    with (ROOT/'data/heights.csv').open(newline='') as f:heights={int(r['height_index']):r for r in csv.DictReader(f)}
    with (ROOT/'data/families.csv').open(newline='') as f:families=list(csv.DictReader(f))
    require(len(families)==1430 and len({r['family_id'] for r in families})==1430,'Family IDs')
    for h in inventory['height_vectors']:
        row=heights[h['index']]
        require([int(row[f'h_{k:02}']) for k in range(36)]==h['integer_heights'],'CSV heights')
        require(bank['height_data'][h['key']]['integer_heights']==h['integer_heights'],'Original heights')
    by_id={r['id']:r for r in bank['families']}
    for row,r in zip(families,inventory['families']):
        require(int(row['family_id'])==r['id'],'CSV family order')
        require(row['phase_bits_p0_first']==r['phase_bits']==by_id[r['id']]['phase_mask'],'Phase bits')
        require(format(int(row['phase_hex_msb_p0'],16),'036b')==r['phase_bits'],'Hex mask convention')
        require(int(row['height_index'])==r['height_index'],'Height association')
    print('PASS: release hashes, original certificate hashes, 103 heights and 1430 families.',flush=True)

def prepare():
    for original,compressed in compressed_files().items():
        target=ROOT/original;raw=gzip.decompress((ROOT/compressed).read_bytes())
        if target.exists():require(target.read_bytes()==raw,'Changed hydrated input: '+original)
        else:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)

def run(command,log):
    with log.open('w',encoding='utf-8') as f:
        subprocess.run([sys.executable,'-B','-u',*map(str,command)],cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,check=True)
    print('PASS:',log.name,flush=True)

def main():
    if not __debug__:raise SystemExit('Assertions are required; do not use Python -O.')
    if sys.version_info<(3,10):raise SystemExit('Python 3.10 or later is required.')
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('mode',choices=['validate','census','lower-bound','paper-points','screen','bindings','entry17','paper','all'])
    ap.add_argument('--output-dir',type=Path)
    args=ap.parse_args();validate()
    if args.mode=='validate':return
    prepare()
    out=(args.output_dir or ROOT/'results'/str(time.time_ns())).resolve()
    require(not out.exists(),'Output directory already exists; choose an unused name.')
    out.mkdir(parents=True)
    if args.mode in ('census','all'):
        run([ROOT/'census/replay_database.py'],out/'type_I.log')
        run([ROOT/'scripts/replay_type_ii.py','--output-dir',out/'type_II'],out/'type_II.log')
    if args.mode in ('lower-bound','all'):
        run([CERT/'research/septic_full_joint_independent_audit_v1.py','--parent','septic_joint_lower_bound_g07','--output',out/'joint_audit'],out/'joint_audit.log')
        d=json.loads((out/'joint_audit.json').read_text())['summary']
        require(d['all_pass'] and d['families']==1430 and d['same_coarse_pairs_checked']==19494 and d['isomorphic_pairs']==0,'Joint audit result')
    if args.mode in ('paper-points','all'):
        run([ROOT/'scripts/replay_paper_points.py','--output',out/'paper_points.json'],out/'paper_points.log')
        d=json.loads((out/'paper_points.json').read_text())
        require(d['all_pass'] and d['families']==1430 and d['pairs']==19494 and d['collisions']==0,'Paper-point result')
    if args.mode in ('screen','all'):
        run([CERT/'research/septic_exact_patchwork_equivalence_screen_v1.py','--parent','septic_joint_lower_bound_g07','--output',out/'coordinate_screen'],out/'coordinate_screen.log')
    if args.mode in ('bindings','all'):
        run([ROOT/'scripts/export_paper_bindings.py','--output-dir',out/'paper_bindings'],out/'paper_bindings.log')
    if args.mode in ('entry17','all'):
        run([ROOT/'scripts/replay_entry17.py','--output',out/'entry17_exact.json'],out/'entry17.log')
    if args.mode in ('paper','all'):
        run([ROOT/'scripts/check_paper_sources.py'],out/'paper_sources.log')
    print('Outputs:',out,flush=True)

if __name__=='__main__':main()
