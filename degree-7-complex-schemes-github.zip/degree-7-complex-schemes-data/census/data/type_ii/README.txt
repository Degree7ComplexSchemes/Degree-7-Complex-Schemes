DETERMINISTIC TYPE II RECOVERY

This supplement replaces the historical-experiment basis of the type II
census with 106 newly recovered and independently replayed witnesses.
The separate 93-entry type I database supplies its exact input seeds.

Input: the 93 type I masks on the 32 triangulations in ../witnesses.json,
including the three original published-input representatives on 7H2.
The three fixed gauge coordinates are (0,0), (1,0), (0,1).
Within each triangulation, seeds are sorted numerically. Free point
indices, then pairs of free indices, are visited in increasing order.

The first pass tests single coefficient reversals. The second pass tests
double reversals and stops as soon as all 106 target schemes are found.
Duplicate masks are discarded per triangulation. Zero Parenti syndromes
are skipped. All other masks are read by unsigned region connectivity.
The optional translated-Gray fallback was not reached in the recorded run.

Recorded result:
  3,069 single-reversal probes recover 105 target schemes.
  Seven double-reversal probes recover the missing pseudoline-only J.
  3,076 attempted probes; 3,068 distinct signed triangulations.
  646 zero-syndrome masks skipped; 2,422 type II real-scheme reads.
  106 distinct real schemes; 13 retained triangulations; no missing target.
  Approximately 0.1 second scanner time, excluding preparation/verification.

FILES
  input.scan: exact scanner input.
  preparation.json: independent cycle equations and source/input hashes.
  results.json: search receipt and masks.
  verified.json: 106 certificates, independent reader and native type checks,
                 exact regularity checks, seed changes, and geometry records.
  witnesses.sqlite: same 106 certificates and 13 triangulation records.
  document_update.json: current paper/source audit binding.
  ../../tools/type_ii_scan.cpp: standard C++17 scanner, no external libraries.
  ../../tools/type_ii_census.py: standard-library preparation and replay tool.

RUN FROM THE PAPER DIRECTORY
  python tools/type_ii_census.py verify

This checks all 106 certificates using the independent bundled reader and
exact integer arithmetic. It writes replay.json and does not replace the
original native-verified certificate. No Sage installation is needed.

To rerun the discovery algorithm with a C++17 compiler:
  g++ -std=c++17 -O3 tools/type_ii_scan.cpp -o type_ii_scan
  ./type_ii_scan data/type_ii/input.scan data/type_ii/results.json 2 65536
  python tools/type_ii_census.py verify

The native primitive-connector replay requires the original repository's
Sage environment and is invoked there with:
  python scripts/type_ii_census.py native

SCOPE
The recovery covers all entries of the known 106-scheme classification.
It is not an exhaustive enumeration of type II coefficient signs and does
not assert a new classification theorem. Nonzero syndrome is a type
certificate, not a real-scheme invariant: each mask is read separately.
