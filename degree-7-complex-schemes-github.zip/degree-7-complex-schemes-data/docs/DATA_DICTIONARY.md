# Data dictionary and conventions

The two inventories serve different purposes. The 93 type I and 106 type II
census witnesses are not the same list as the 1430 separated families.

## Section 10

`data/lattice_points.csv` fixes zero-based indices: `(0,0),...,(0,7),
(1,0),...,(1,6),...,(7,0)`. The third exponent is `7-i-j`.

`data/heights.csv` has 103 rows. `height_index` is the index used in the
removed table; `height_key` is the original SHA-derived identifier.
The 36 integer columns `h_00` through `h_35` follow the lattice-point order.

`data/families.csv` has 1430 rows. `phase_bits_p0_first[k]` is the sign bit
of the coefficient at point `k`; bit 0 means +1 and bit 1 means -1.
`phase_hex_msb_p0` encodes that string as a 36-bit integer with point 0
in the most significant position. Keep leading zeros. Thus `000000001`
makes only the coefficient of `X^7` negative. The type and scheme fields
are audited metadata, not substitutes for replay.

For a row with height vector `h` and phase bits `b`, the polynomial is

```text
F_t(X,Y,Z) = sum_k (-1)^b[k] t^h[k] X^i[k] Y^j[k] Z^(7-i[k]-j[k]).
```

The construction and marked-point sign claims apply for sufficiently small
positive `t`. The exact sign calculation uses Laurent polynomials and
their first nonzero coefficients, not a floating-point evaluation at a
chosen decimal parameter. The historical certificate's special endpoint
`t=2^-1000` does not assert validity of the point formulas at that endpoint.

`data/construction_inventory.json` contains the same data, the 49 triangles
for each lifting, and the recorded schemes. The triangles can also be
recovered from strict supporting planes of the height vector.

Scheme arrays in the separation bank:

- Type II: `['unnested',r]`, `['nest',alpha,beta]`, or `['deep']`.
- Type I: `['unnested',[positive,negative]]`,
  `['nest',[outer_positive,outer_negative],container_sign,[inner_positive,inner_negative]]`,
  or `['deep',[outer_sign,middle_sign,inner_sign]]` with integer signs +/-1.
- The unique pseudoline is implicit in these arrays.

## Earlier census: opposite hexadecimal convention

In `census/data/witnesses.json` and `census/data/type_ii/`, point 0 is the
**least significant** bit of `mask_hex`:

```python
census_bits = [(int(mask_hex,16) >> k) & 1 for k in range(36)]
section10_bits = [int(c) for c in format(int(mask_hex,16),'036b')]
```

Do not compare the two hexadecimal strings directly without converting
their pointwise bits. The shipped replay programs already use the correct
convention for their own inputs.

## Relations and reproducibility

Small-oval labels carry inner/exterior roles and, in type I, complex signs.
Protected triples have at least one inner label. Eligible mixed sextuples
are the union of tests A, B and C in the manuscript. Isomorphism must use
one common color-preserving bijection for all signs, one common +/-1
multiplier for triples, and permutation parity for conics. Conic signs
receive no global multiplier. Equal relations do not imply rigid isotopy.
