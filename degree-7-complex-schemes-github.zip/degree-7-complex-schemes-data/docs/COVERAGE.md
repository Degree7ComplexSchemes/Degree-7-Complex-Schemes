# Reproducibility coverage for companion version 1.1.0

The claim-by-file index is `CLAIM_FILE_MAP.csv`. The optimized remaining
mathematical obligations are `referee-queries.json` and `REFEREE_CHECKLIST.md`.

## Exact portable checks

- All original release hashes, 103 liftings and 1430 family associations.
- The 93 retained type I complex schemes and 106 retained type II schemes,
  with exact syndrome, regularity and independent region-reader checks.
- The original whole-bank triple/conic calculations and all 19494 within-
  group relation comparisons, plus the article's independent marked-point replay.
- New paper-binding exports: 13835 small-oval point records in 1409 families,
  including signed vertices, coherent lift signs, rational exponents and
  positive dominance gaps; the 21 scheme-only records are singleton gamma
  classes among the entire finite bank.
- New entry-17 replay: all 14 words, complete Seifert and symmetric matrices,
  pivots, determinant -80 and inertia (11,21,0), checked by integer and rational
  congruence elimination. This checks a shared Seifert construction by two
  elimination methods; it is not a separate derivation of that construction.
- Article/file bindings, 93 printed census masks, 167 transcribed table entries,
  nine side-margin queries and the compact figure-source layout.

## Graphics and typesetting

Both final sets of 93 dividing and 106 nondividing curves include triangulations.
Their 199 vector panels, sources, settings and check reports are in `plates/`.
SageMath is optional for regenerating geometry; it is not required for core
mathematical replay. The complete current article and all its figure/table
assets are in `paper/`. The supplied entry-17 image is restored, and the
entry-2 drawing is regenerated directly from the manuscript's Artin word.
No missing-image placeholder is used. Figure-only floats and landscape pages
are disabled; the article retains numbered queries in the side margins.

## What is not certified by a successful replay

The geometric pencil-exhaustion, fold-transport, ramification-surface,
half-surface and relative-isotopy arguments remain mathematical obligations.
The native primitive-connector census checks are preserved as historical
receipts, rather than claimed to rerun in the portable command.

Entry-2 covering/inertia and Floer packages in `obstructions/` are archival
supplements. They are not part of core `all`. The Floer summary expressly
does not certify a whole-scheme exclusion. Complete indexed C-complex inputs
and an exact matrix certificate binding the stated W_plus to (-8,0) are not
supplied; query Q7 asks for those inputs and the admissibility verification.
Row 166 and its three-pencil obstruction are therefore explicitly proposed.

The three published additional complex schemes and the jump/no-jump pair
still rely on the mathematical sources cited by the paper. The finite bank
does not prove global coverage, global connectivity, a numerical upper bound,
or an exact count of septic rigid-isotopy classes. Source compilation likewise
does not establish mathematical correctness.
