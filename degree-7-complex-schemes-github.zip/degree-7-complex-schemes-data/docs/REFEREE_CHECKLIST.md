# Referee verification priorities

The short versions remain in the manuscript side margins. These requests are open mathematical obligations, not tasks discharged by successful compilation or numerical replay.

## Q1 — lem:exterior-pencil-strip

Does the sweep exclude extra arcs and closed components in each gap, and give one common conversion from strip signs to $J$-relative signs? These are needed for the claimed single alternating chain.

Required evidence: Prove the global sweep/exhaustion statement, including folds on persistent branches, then check the tangency-to-oval sign convention. Local Bezout counts alone must not be used as a classification of all gap components.

## Q2 — thm:entry-two-iterated-cover

Is the branched-cover surface exactly the ramification disk plus the unbranched lift of $N^-$, with no extra components? Check its boundary, orientations, and Euler characteristic before applying the signature inequality.

Required evidence: Give a surface-level identification in the cyclic cover of the four-ball branched over the unknotted degree-one disk, including the boundary map and the Euler characteristic of every component. The word/inertia replay is not this identification.

## Q3 — eq:entry-two-mixed-rewrite

Do the six rewrite cases, with the stated marked-strand and closure conventions, give the geometric input to each inverse-image map? The faithful Artin-action checks establish word equality, not the branched-cover identification.

Required evidence: Verify the six local cases with a labeled diagram, the moving distinguished strand, closure transport, and the input convention of the iterated covering map. Existing exact words and pivots should be used, not requested again.

## Q4 — thm:violet-one-three-pencil

Does the negative-degree branch force adjacent endpoint folds? Can the separate fold cancellations preserve the original joining-line sectors and complex orientations used simultaneously in all three pencils?

Required evidence: Prove the endpoint-fold connection from the degree count and the absence of internal critical values. State precisely which incidence/sector data remain constraints on one original curve after different pencil normalizations.

## Q5 — thm:violet-one-three-pencil

Do the stored braid words and planar diagrams represent the four-band knots with the stated orientations and genus bound? Check the exceptional $P'$ closure as well as the numerical Floer outputs.

Required evidence: Bind every printed row to a stored word, fusion suffix, planar diagram, orientation and Floer result; certify the genus-five bounding surface. Recomputing tau for a diagram alone does not identify it with a hypothetical pencil knot.

## Q6 — thm:violet-one-three-pencil

Do the two sector inequalities force the entire ordered word $W_+$? If they permit other words, enumerate and obstruct all of them before concluding that the scheme is excluded.

Required evidence: Prove uniqueness of the full word, or provide a complete finite list with a geometric exhaustion proof. The stated determinant signs presently select sectors; this is not automatically a complete pencil-word reconstruction.

## Q7 — thm:violet-one-three-pencil

Are these characters admissible for the colored-link inequality? Supply the colored diagram or C-complex, indexed matrices, and exact inertia certificate for $(-8,0)$; also justify the surface bound $b_1(N)=7$.

Required evidence: Provide a complete binding of W_+ and half-colors to a C-complex, generalized Seifert matrices, the two rational unit characters, and exact Hermitian elimination. Verify all admissibility and connectedness hypotheses. An archival computation for another scheme is not a substitute.

## Q8 — thm:pencil-half-genus-obstruction

Do the normalized pencil and half-color conventions put the two chain strings in opposite halves and give $T=D-\sigma$? Check these topological inputs to the genus calculation, rather than only its final algebra.

Required evidence: Verify nonemptiness and connectedness of the two half-surfaces after the cited fold moves; derive the assigned subbraid strands and boundary circles and the signed small-oval contribution. The displayed Euler-characteristic algebra is then immediate.

## Q9 — thm:degree-seven-lower-bound

Does the moment-map argument give the required relative ambient isotopy across coordinate faces, fixing vertex neighborhoods and identifying the same oriented components as Parenti? This geometric correspondence is not a consequence of the finite-bank replay.

Required evidence: Check the boundary-face gluing, the passage from uniform convergence plus component counts to relative ambient isotopy, and the comparison with the complex-oriented patchworking branches. Finite marked-point and singleton-scheme certificates are now supplied separately.

