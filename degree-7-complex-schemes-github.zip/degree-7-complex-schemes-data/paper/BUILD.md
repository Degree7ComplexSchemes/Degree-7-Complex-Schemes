# Building the arXiv-formatted review version

Main file: `main.tex`. Run pdfLaTeX twice from this folder:

```text
pdflatex -no-shell-escape -halt-on-error main.tex
pdflatex -no-shell-escape -halt-on-error main.tex
```

The source uses standard AMS, graphics, TikZ, longtable, microtype, hyperref
and cleveref packages. The bibliography is inside main.tex; no external
BibTeX input is needed. No shell escape or data download is used. Include
reproducibility.tex, tables/excluded-candidates.tex and the entire figures/
folder in a source submission. The individual curve plate sets are cited
from the GitHub companion and need not be uploaded to typeset the article.

The desktop editor's built-in compiler successfully compiled this saved
project after the formatting changes. That is not a claim of compilation
on arXiv's servers or of arXiv acceptance. The source ZIP is a compact set
of typesetting inputs, not the full computational companion.

All nine referee queries remain in the side margins. The landscape figure
layout and figure-only float option are removed, and each diagram is fitted
to at most 32% of text height to share its page with prose. The long exclusion
table is a readable, page-breaking longtable rather than a five-point image.
Row 166 is explicitly a proposed exclusion pending its verification queries.
Formatting and successful exact numerical checks do not close open proofs.

Preparation guidance: https://info.arxiv.org/help/submit_tex.html
