"""Recover tau from the saved UV=0 complex using independent F2 elimination."""
from pathlib import Path
import sys, json
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'tmp/floer_dependencies'),str(ROOT/'scripts')]
import knot_floer_homology as hfk


def reduce_vector(x,pivots):
    while x:
        k=x.bit_length()-1
        if k not in pivots:return x
        x^=pivots[k]
    return 0


def basis(vectors):
    pivots={}
    for x in vectors:
        x=reduce_vector(x,pivots)
        if x:pivots[x.bit_length()-1]=x
    return pivots


def kernel_relations(columns):
    pivots={};relations=[]
    for i,col in enumerate(columns):
        x,r=col,1<<i
        while x:
            k=x.bit_length()-1
            if k not in pivots:
                pivots[k]=(x,r);break
            a,b=pivots[k];x^=a;r^=b
        if not x:relations.append(r)
    return relations


def recover_tau(data):
    gen=data['generators'];diff=data['differentials']
    vertical={k:v for k,v in diff.items() if gen[k[0]][1]==gen[k[1]][1]+1 and v%2}
    zero=[k for k,(a,m) in gen.items() if m==0]
    minus=[k for k,(a,m) in gen.items() if m==-1]
    plus=[k for k,(a,m) in gen.items() if m==1]
    zi={k:i for i,k in enumerate(zero)};mi={k:i for i,k in enumerate(minus)}
    columns={k:0 for k in zero};boundaries=[]
    for a,b in vertical:
        assert gen[b][0]<=gen[a][0]
        if a in zi:columns[a]^=1<<mi[b]
    for k in plus:
        boundaries.append(sum(1<<zi[b] for a,b in vertical if a==k))
    bp=basis(boundaries)
    for boundary in boundaries:
        image=0
        for k,i in zi.items():
            if boundary>>i&1:image^=columns[k]
        assert image==0,'vertical differential does not square to zero'
    all_kernel=kernel_relations([columns[k] for k in zero])
    assert len(all_kernel)-len(bp)==1
    for level in sorted(set(a for a,m in gen.values())):
        selected=[k for k in zero if gen[k][0]<=level]
        relations=kernel_relations([columns[k] for k in selected])
        for rel in relations:
            cycle=sum(1<<zi[k] for i,k in enumerate(selected) if rel>>i&1)
            if reduce_vector(cycle,bp):
                return dict(tau=level,maslov_zero_generators=len(zero),
                            boundary_rank=len(bp),vertical_homology_rank=1)
    raise RuntimeError('No generator of HFhat found')


def run(index=0,variant=None):
    suffix=f'_variant{variant:02}' if variant is not None else ''
    path=ROOT/'output/violet_floer_fusion_receipts'/f'entry1_{index:03}{suffix}.json'
    r=json.loads(path.read_text());pd=r['knot_floer']['pd_code']
    data=hfk.pd_to_hfk(pd,complex=True)
    check=recover_tau(data)
    assert check['tau']==r['knot_floer']['tau']==data['tau']
    mirror=hfk.pd_to_hfk([(a,d,c,b) for a,b,c,d in pd])
    assert mirror['tau']==-data['tau']
    result=dict(entry=1,index=index,variant=variant,independent_vertical_check=check,
                mirror_tau=mirror['tau'],
                complex=dict(generators=[[k,a,m] for k,(a,m) in data['generators'].items()],
                             differentials=[[a,b,v] for (a,b),v in data['differentials'].items()]))
    destination=ROOT/'output'/f'violet1_floer_chain_check_{index:03}{suffix}.json'
    destination.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(index=index,check=check,mirror_tau=mirror['tau'])),flush=True)


if __name__=='__main__':
    run(int(sys.argv[1]) if len(sys.argv)>1 else 0,
        int(sys.argv[2]) if len(sys.argv)>2 else None)
