"""Recompute the 21 obstructing complexes and check their vertical algebra.

The complexes come from Szabo's calculator. The F2 elimination below is a
separate algebra check, not an independent construction of knot Floer theory
and not a verification of the geometric preparation theorem.
"""

from collections import defaultdict
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "tmp/floer_dependencies"), str(ROOT / "scripts"),
                str(ROOT / "tmp"), str(ROOT)]

import knot_floer_homology as hfk
from violet_floer_chain_check import basis, recover_tau
from violet_floer_fusion_audit import cycles
from scripts.audit_table19_entry2_cover import pencil_braid
from table20_pencil_audit import family, TARGETS


def vertical_algebra(data):
    generators = data["generators"]
    outgoing = {key: 0 for key in generators}
    labels = {key: index for index, key in enumerate(generators)}
    groups = defaultdict(list)
    for key, (_, maslov) in generators.items():
        groups[maslov].append(key)
    for (source, target), coefficient in data["differentials"].items():
        if coefficient % 2 and generators[source][1] == generators[target][1] + 1:
            assert generators[target][0] <= generators[source][0]
            outgoing[source] ^= 1 << labels[target]
    keys = list(generators)
    for image in outgoing.values():
        square = 0
        while image:
            bit = image & -image
            square ^= outgoing[keys[bit.bit_length() - 1]]
            image ^= bit
        assert square == 0
    ranks = {m: len(basis([outgoing[key] for key in group]))
             for m, group in groups.items()}
    homology = {m: len(group) - ranks[m] - ranks.get(m + 1, 0)
                for m, group in groups.items()}
    assert all(dimension >= 0 for dimension in homology.values())
    assert {m: n for m, n in homology.items() if n} == {0: 1}
    return {"differential_squared_zero_all_generators": True,
            "vertical_homology_by_maslov": {"0": 1},
            "filtered_generator_check": recover_tau(data)}


def main():
    output = ROOT / "output/violet1_full_floer_recheck"
    output.mkdir(exist_ok=True)
    receipts = ROOT / "output/violet_floer_fusion_receipts"
    words = family(TARGETS[1])[1]
    paths = [receipts / f"entry1_{index:03}.json"
             for index in range(24) if index not in (2, 6, 18, 23)]
    paths.append(receipts / "entry1_002_variant01.json")
    paths.sort()
    rows = []
    for path in paths:
        record = json.loads(path.read_text())
        index = int(path.stem.split("_")[1])
        assert record["bands"] == words[index]
        word = pencil_braid(record["bands"])
        for step in record["surgery_steps"]:
            first, second = step["endpoints"]
            before = cycles(word)
            assert next(c for c in before if first in c) != next(c for c in before if second in c)
            word += step["band_word"]
            assert cycles(word) == step["cycles_after"]
        assert word == record["knot_braid"] and len(cycles(word)) == 1
        assert record["required_knot_genus"] == 5
        assert 7 - sum(1 if x > 0 else -1 for x in word) == -9
        pd = record["knot_floer"]["pd_code"]
        data = hfk.pd_to_hfk(pd, complex=True)
        algebra = vertical_algebra(data)
        tau = algebra["filtered_generator_check"]["tau"]
        assert tau == data["tau"] == record["knot_floer"]["tau"] == 6
        mirror = hfk.pd_to_hfk([(a, d, c, b) for a, b, c, d in pd])
        assert mirror["tau"] == -tau
        complex_data = {
            "generators": [[key, a, m] for key, (a, m) in sorted(data["generators"].items())],
            "differentials": [[a, b, v] for (a, b), v in sorted(data["differentials"].items())],
        }
        encoded = json.dumps(complex_data, sort_keys=True).encode("ascii")
        row = {"receipt": path.name, "index": index, "tau": tau,
               "mirror_tau": mirror["tau"], "surface_genus_bound": 5,
               "generator_count": len(data["generators"]),
               "complex_sha256": hashlib.sha256(encoded).hexdigest(),
               "vertical_algebra": algebra}
        (output / path.name).write_text(json.dumps({**row, "pd_code": pd,
                                                  "complex": complex_data}, indent=2) + "\n")
        rows.append(row)
        print(json.dumps({"completed": len(rows), "total": 21,
                          "index": index, "tau": tau, "mirror_tau": mirror["tau"]}), flush=True)
    assert len(rows) == 21 and len({row["index"] for row in rows}) == 21
    report = {"status": "all 21 obstructing complexes freshly recomputed",
              "calculator_version": hfk.__version__, "records": rows,
              "all_vertical_differentials_checked": True,
              "all_tau_values_recovered_by_f2_elimination": True,
              "all_mirror_signs_checked": True,
              "independent_complex_construction": False,
              "geometric_preparation_verified_by_this_script": False}
    (output / "summary.json").write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
