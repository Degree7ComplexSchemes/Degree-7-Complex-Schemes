"""Floer tests of explicit saddle fusions of the conditional pencil families.

No geometric exhaustion of the normal forms is claimed. The knot tau screen
is independent of a Liu h-function computation, which this script does not do.
Dependencies are isolated under tmp/floer_dependencies.
"""
from pathlib import Path
import sys, json, time, random, subprocess, argparse

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / 'tmp/floer_dependencies'), str(ROOT / 'tmp'), str(ROOT)]
from table20_pencil_audit import family, TARGETS, subbraid
from scripts.audit_table19_entry2_cover import pencil_braid, inverse

POS = {3, 4, 6}
NEG = set(range(1, 8)) - POS


def cycles(word, n=7):
    p = list(range(1, n + 1))
    for x in word:
        i = abs(x) - 1
        p[i], p[i + 1] = p[i + 1], p[i]
    seen, result = set(), []
    for j in range(1, n + 1):
        if j in seen:
            continue
        c, k = [], j
        while k not in seen:
            seen.add(k); c.append(k); k = p[k - 1]
        result.append(c)
    return result


def band(i, j, sign=1):
    transport = list(range(j - 1, i, -1))
    return transport + [sign * i] + inverse(transport)


def cross_linking(word, plus=POS):
    labels, signed_crossings = list(range(1, 8)), 0
    for x in word:
        i = abs(x) - 1
        if (labels[i] in plus) != (labels[i + 1] in plus):
            signed_crossings += 1 if x > 0 else -1
        labels[i], labels[i + 1] = labels[i + 1], labels[i]
    assert signed_crossings % 2 == 0
    return signed_crossings // 2


def fusion(entry, bands):
    word = pencil_braid(bands)
    assert cycles(word) == [[1, 7], [2], [3], [4, 6], [5]]
    original_chi = 7 - sum(1 if x > 0 else -1 for x in word)
    assert original_chi == ( -5 if entry == 1 else -3 )
    steps = []
    # Each central crossing is an oriented saddle; transport and its inverse
    # specify its embedded boundary band and are not additional saddles.
    for i, j in [(1, 2), (3, 4), (5, 7), (2, 3)]:
        before = cycles(word)
        ci = next(k for k, c in enumerate(before) if i in c)
        cj = next(k for k, c in enumerate(before) if j in c)
        assert ci != cj, (entry, bands, i, j, before)
        b = band(i, j)
        word += b
        assert len(cycles(word)) == len(before) - 1
        steps.append(dict(endpoints=[i, j], band_word=b, cycles_after=cycles(word)))
        if len(steps) == 3:
            color_word = list(word)
            assert cross_linking(color_word) == 0
            assert all(all(k in POS for k in c) or all(k in NEG for k in c)
                       for c in cycles(color_word))
    assert len(cycles(word)) == 1
    chi = original_chi - 4
    assert (1 - chi) % 2 == 0
    return dict(entry=entry, bands=bands, original_chi=original_chi,
                surgery_steps=steps, color_fused_braid=color_word,
                color_linking_number=0, knot_braid=word,
                required_knot_genus=(1 - chi)//2,
                required_color_genera=[1, 4 if entry == 1 else 3])


def hfk_braid(word, seed):
    import spherogram, knot_floer_homology as hfk
    random.seed(seed)
    link = spherogram.Link(braid_closure=word)
    assert len(link.link_components) == 1
    before = len(link.crossings)
    link.simplify('global')
    assert len(link.link_components) == 1
    pd = link.PD_code()
    if not pd:
        return dict(tau=0, nu=0, epsilon=0, seifert_genus=0, total_rank=1,
                    ranks=[[0, 0, 1]], pd_code=[], input_crossings=before,
                    simplified_crossings=0)
    result = hfk.pd_to_hfk(pd)
    result['ranks'] = [[a, m, n] for (a, m), n in sorted(result['ranks'].items())]
    result.update(pd_code=pd, input_crossings=before, simplified_crossings=len(pd))
    assert sum(n for a, m, n in result['ranks']) == result['total_rank']
    assert sum((-1)**m*n for a, m, n in result['ranks']) == 1
    return result


def worker(entry, index, out):
    bands = family(TARGETS[entry])[1][index]
    record = fusion(entry, bands)
    start = time.monotonic()
    record['knot_floer'] = hfk_braid(record['knot_braid'], 1000*entry+index)
    record['strict_tau_obstruction'] = abs(record['knot_floer']['tau']) > record['required_knot_genus']
    record['elapsed_seconds'] = time.monotonic()-start
    Path(out).write_text(json.dumps(record, indent=2)+'\n')


def run(entry, limit=None):
    directory = ROOT / 'output' / 'violet_floer_fusion_receipts'
    directory.mkdir(exist_ok=True)
    words = family(TARGETS[entry])[1]
    count = len(words) if limit is None else min(limit,len(words))
    records, errors = [], []
    for index in range(count):
        path = directory / f'entry{entry}_{index:03}.json'
        if not path.exists():
            try:
                p = subprocess.run([sys.executable, str(Path(__file__).resolve()), '--worker',
                                    str(entry), str(index), str(path)],
                                   capture_output=True,text=True,timeout=90,cwd=ROOT)
                if p.returncode:
                    errors.append(dict(index=index,error=p.stderr[-2500:]));continue
            except subprocess.TimeoutExpired:
                errors.append(dict(index=index,error='90 second computation timeout'));continue
        record=json.loads(path.read_text());records.append(record)
        print(json.dumps(dict(entry=entry,index=index,tau=record['knot_floer']['tau'],
                              bound=record['required_knot_genus'],
                              obstruction=record['strict_tau_obstruction'],
                              seconds=round(record['elapsed_seconds'],2))),flush=True)
        summary = dict(status='conditional_normal_form_family_only',entry=entry,
                       family_size=len(words),attempted=count,completed=len(records),
                       strict_tau_obstructions=sum(r['strict_tau_obstruction'] for r in records),
                       errors=errors,records=records,whole_scheme_excluded=False,
                       joint_link_h_function_computed=False)
        (ROOT/'output'/f'violet{entry}_floer_fusion_audit.json').write_text(json.dumps(summary,indent=2)+'\n')


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--worker',nargs=3)
    parser.add_argument('--entry',type=int,default=1)
    parser.add_argument('--limit',type=int)
    args=parser.parse_args()
    if args.worker:
        worker(int(args.worker[0]),int(args.worker[1]),args.worker[2])
    else:
        run(args.entry,args.limit)
