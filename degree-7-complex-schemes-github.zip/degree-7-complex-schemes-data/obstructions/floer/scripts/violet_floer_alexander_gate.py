"""Exact Fox-calculus gate for using the L-space Alexander shortcut.

Alexander data are not substituted for Floer h-data on a general link.
"""
from pathlib import Path
import sys,json,time
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'tmp/floer_dependencies'),str(ROOT/'scripts')]
import sympy as S
from sympy.polys.matrices import DomainMatrix
from violet_floer_fusion_audit import POS,cycles
x,y=S.symbols('x y')


def jacobian(word,colors):
    n=len(colors);t=[x if c==0 else y for c in colors]
    d=S.eye(n)
    for g in word:
        k=abs(g)-1;a,b=d.row(k),d.row(k+1);A,B=t[k:k+2]
        if g>0:
            na=(1-B)*a+A*b;nb=a
        else:
            na=b;nb=(a+(A-1)*b)/B
        for j in range(n):d[k,j]=S.expand(na[j]);d[k+1,j]=S.expand(nb[j])
        t[k],t[k+1]=B,A
    assert t==[x if c==0 else y for c in colors]
    rel=d-S.eye(n)
    # Fox fundamental identity supplies the expected right kernel.
    assert all(S.expand(sum(rel[i,j]*(t[j]-1) for j in range(n)))==0 for i in range(n))
    return rel


def cofactor(rel,row,col):
    m=rel.minor_submatrix(row,col)
    for i in range(m.rows):
        terms=[term for z in m.row(i) for term in S.Add.make_args(S.expand(z)) if term]
        ax=min([int(z.as_powers_dict().get(x,0)) for z in terms]+[0])
        ay=min([int(z.as_powers_dict().get(y,0)) for z in terms]+[0])
        for j in range(m.cols):m[i,j]=S.expand(m[i,j]*x**(-ax)*y**(-ay))
    determinant=DomainMatrix.from_Matrix(m).det().as_expr()
    return S.Poly(determinant,x,y)


def run(index):
    start=time.monotonic()
    r=json.loads((ROOT/'output/violet_floer_fusion_receipts'/f'entry1_{index:03}.json').read_text())
    word=r['color_fused_braid'];colors=[0 if j in POS else 1 for j in range(1,8)]
    assert len(cycles(word))==2
    j=jacobian(word,colors)
    p=cofactor(j,6,6)
    q,remainder=p.div(S.Poly(y-1,x,y));assert remainder.is_zero
    # A second minor has the same Alexander coefficients up to a Laurent unit.
    p2=cofactor(j,5,6);q2,rem2=p2.div(S.Poly(y-1,x,y));assert rem2.is_zero
    def normalize(poly):
        terms=poly.terms()
        if not terms:return []
        lo=[min(e[k] for e,c in terms) for k in range(2)]
        return sorted((e[0]-lo[0],e[1]-lo[1],int(c)) for e,c in terms)
    n1,n2=normalize(q),normalize(q2)
    assert n1==n2 or n1==[(a,b,-c) for a,b,c in n2]
    assert S.expand(q.as_expr().subs(y,1))==0
    assert S.expand(q.as_expr().subs(x,1))==0
    max_coefficient=max([abs(c) for a,b,c in n1]+[0])
    result=dict(entry=1,index=index,terms=n1,maximum_absolute_coefficient=max_coefficient,
                second_minor_matches=True,torres_zero_linking_checks=True,
                l_space_coefficient_necessary_condition=max_coefficient<=1,
                joint_h_function_computed=False,seconds=time.monotonic()-start)
    (ROOT/'output'/f'violet1_floer_alexander_gate_{index:03}.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='terms'}),flush=True)


if __name__=='__main__':
    # Hopf-link calibration: Alexander polynomial is a Laurent unit.
    h=jacobian([1,1],[0,1]);p=cofactor(h,1,1)
    q,rem=p.div(S.Poly(y-1,x,y));assert rem.is_zero and len(q.terms())==1
    run(int(sys.argv[1]) if len(sys.argv)>1 else 6)
