"""Additional explicit, positive-band knot fusions; conditional braid tests."""
from pathlib import Path
import sys,json,time,subprocess
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'tmp'),str(ROOT)]
from violet_floer_fusion_audit import cycles,band,hfk_braid,cross_linking,POS,NEG
from table20_pencil_audit import family,TARGETS
from scripts.audit_table19_entry2_cover import pencil_braid


def variants():
    # After (1,2), the two residual negative components can be joined at
    # (5,7), (2,5), or (1,5). Both positive choices merge [3] with [4,6].
    for positive in [(3,4),(3,6)]:
        for negative in [(5,7),(2,5),(1,5)]:
            for across in [(2,3),(4,5),(5,6),(6,7)]:
                yield [(1,2),positive,negative,across]


def record(entry,index,vindex):
    pairs=list(variants())[vindex]
    bands=family(TARGETS[entry])[1][index];word=pencil_braid(bands)
    steps=[]
    for k,(i,j) in enumerate(pairs):
        before=cycles(word)
        assert next(c for c in before if i in c)!=next(c for c in before if j in c)
        bw=band(i,j);word+=bw
        assert len(cycles(word))==len(before)-1
        if k==2:assert cross_linking(word)==0
        steps.append(dict(endpoints=[i,j],band_word=bw,cycles_after=cycles(word)))
    bound=5 if entry==1 else 4
    start=time.monotonic();r=hfk_braid(word,100000*entry+100*index+vindex)
    return dict(entry=entry,index=index,bands=bands,variant=vindex,
                surgery_steps=steps,knot_braid=word,required_knot_genus=bound,
                knot_floer=r,strict_tau_obstruction=abs(r['tau'])>bound,
                elapsed_seconds=time.monotonic()-start)


def run(entry,index,limit=24):
    directory=ROOT/'output/violet_floer_fusion_receipts';records=[];errors=[]
    for vi in range(limit):
        path=directory/f'entry{entry}_{index:03}_variant{vi:02}.json'
        if not path.exists():
            try:
                p=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--worker',
                                  str(entry),str(index),str(vi),str(path)],
                                 capture_output=True,text=True,timeout=75,cwd=ROOT)
                if p.returncode:
                    errors.append(dict(variant=vi,error=p.stderr[-1500:]));continue
            except subprocess.TimeoutExpired:
                errors.append(dict(variant=vi,error='75 second timeout'));continue
        r=json.loads(path.read_text());records.append(r)
        print(json.dumps(dict(entry=entry,index=index,variant=vi,tau=r['knot_floer']['tau'],
                              bound=r['required_knot_genus'],strict=r['strict_tau_obstruction'],
                              seconds=round(r['elapsed_seconds'],2))),flush=True)
        summary=dict(entry=entry,index=index,records=records,errors=errors,
                     conditional_word_excluded=any(x['strict_tau_obstruction'] for x in records),
                     whole_scheme_excluded=False,joint_link_h_function_computed=False)
        (ROOT/'output'/f'violet{entry}_floer_variants_{index:03}.json').write_text(json.dumps(summary,indent=2)+'\n')
        if r['strict_tau_obstruction']:break


if __name__=='__main__':
    if sys.argv[1]=='--worker':
        r=record(*map(int,sys.argv[2:5]));Path(sys.argv[5]).write_text(json.dumps(r,indent=2)+'\n')
    else:run(int(sys.argv[1]),int(sys.argv[2]),int(sys.argv[3]) if len(sys.argv)>3 else 24)
