"""Finite pencil-family tests for Table20; geometry remains a separate proof.

All signatures here are exact at the explicitly listed rational unit-circle
parameters. Failure to find an obstruction is not a realization certificate.
"""
from itertools import combinations, product
from pathlib import Path
import json
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scripts.audit_table19_entry2_cover import (
    annular_rewrite, covering_braid, pencil_braid, reduce_word, seifert_matrix,
)
from scripts.audit_table19_entry2_family import orientation_ledger
from scripts.entry2_sparse_inertia import sparse_inertia


TARGETS = {
    1: dict(outer_plus=0, outer_minus=3, inner_plus=3, inner_minus=4,
            nonempty_plus=True, selected_inner_plus=False),
    2: dict(outer_plus=1, outer_minus=2, inner_plus=4, inner_minus=5,
            nonempty_plus=True, selected_inner_plus=False),
    3: dict(outer_plus=0, outer_minus=4, inner_plus=2, inner_minus=0,
            nonempty_plus=True, selected_inner_plus=True),
    4: dict(outer_plus=0, outer_minus=4, inner_plus=1, inner_minus=1,
            nonempty_plus=False, selected_inner_plus=False),
    5: dict(outer_plus=0, outer_minus=5, inner_plus=1, inner_minus=2,
            nonempty_plus=True, selected_inner_plus=False),
}


def family(target):
    outer = target['outer_plus'] + target['outer_minus']
    inner = target['inner_plus'] + target['inner_minus'] - 2
    residual_plus = target['inner_plus'] - 1 - target['selected_inner_plus']
    count = outer + inner
    raw = 0
    accepted = []
    for exterior_positions in combinations(range(count), outer):
        for exterior_bands in product((3, 4), repeat=outer):
            raw += 1
            bands = [2] * count
            for p, b in zip(exterior_positions, exterior_bands):
                bands[p] = b
            ledger = orientation_ledger(bands)
            if ledger is None:
                continue
            if sum(ledger[p]['positive_oval'] for p in exterior_positions) != target['outer_plus']:
                continue
            if sum(ledger[p]['positive_oval'] for p in range(count)
                   if p not in exterior_positions) != residual_plus:
                continue
            accepted.append(bands)
    return raw, accepted


def subbraid(word, labels, strands=7):
    positions = list(range(1, strands + 1))
    result = []
    for x in word:
        i = abs(x) - 1
        if positions[i] in labels and positions[i + 1] in labels:
            k = sum(y in labels for y in positions[:i + 1])
            result.append(k if x > 0 else -k)
        positions[i], positions[i + 1] = positions[i + 1], positions[i]
    if any((i in labels) != (label in labels)
           for i, label in enumerate(positions, 1)):
        raise ArithmeticError('Subset is not a union of closed components')
    return reduce_word(result)


def signature(word, strands, slope):
    if not word:
        return dict(inertia=(0, 0, 0), signature=0,
                    adjusted_nullity=strands, dimension=0)
    v = seifert_matrix(word, strands)
    inertia, _ = sparse_inertia(v, slope=slope)
    return dict(inertia=inertia, signature=inertia[0] - inertia[1],
                adjusted_nullity=1 + inertia[2], dimension=len(v))


def audit(entry, target, slopes=(1, 4, 25)):
    raw, bands_family = family(target)
    plus = {3}
    if target['nonempty_plus']:
        plus |= {4, 6}
    if target['selected_inner_plus']:
        plus |= {1, 7}
    minus = set(range(1, 8)) - plus
    records = []
    for bands in bands_family:
        word = pencil_braid(bands)
        partition = {name: subbraid(word, labels)
                     for name, labels in [('plus', plus), ('minus', minus)]}
        partitions = {}
        for name, labels in [('plus', plus), ('minus', minus)]:
            u = partition[name]
            chi = len(labels) - sum(1 if x > 0 else -1 for x in u)
            observations = []
            for slope in slopes:
                obs = dict(slope=slope, **signature(u, len(labels), slope))
                obs['surface_bound'] = -chi
                obs['strict_obstruction'] = abs(obs['signature']) - obs['adjusted_nullity'] > -chi
                observations.append(obs)
            partitions[name] = dict(initial_labels=sorted(labels), braid=u,
                                    chi=chi, observations=observations)
        full_chi = 7 - sum(1 if x > 0 else -1 for x in word)
        full = []
        for slope in slopes:
            obs = dict(slope=slope, **signature(word, 7, slope))
            obs['surface_bound'] = -full_chi
            obs['strict_obstruction'] = abs(obs['signature']) - obs['adjusted_nullity'] > -full_chi
            full.append(obs)
        records.append(dict(bands=bands, base_braid=word,
                            complex_halves=partitions, full=full))
    return dict(entry=entry, raw_words=raw, admissible_words=len(bands_family),
                target=target, records=records)


def entry_four_disk_covers():
    word = pencil_braid([3, 4, 3, 4])
    strands, branch = 7, 3
    observations = []
    for degree, slope in [(1, 25), (2, 25), (4, 25), (8, 100)]:
        if degree > 1:
            annular, _ = annular_rewrite(word, strands, branch)
            word = covering_braid(annular, strands)
            strands, branch = 2 * strands - 1, strands
        obs = dict(cover_degree=degree, slope=slope, strands=strands,
                   branch=branch, word_length=len(word),
                   **signature(word, strands, slope))
        obs['surface_bound'] = 10 * degree - 1
        obs['strict_obstruction'] = abs(obs['signature']) - obs['adjusted_nullity'] > obs['surface_bound']
        observations.append(obs)
    return observations


if __name__ == '__main__':
    result = []
    for entry, target in TARGETS.items():
        record = audit(entry, target)
        result.append(record)
        survivors = sum(not any(o['strict_obstruction'] for p in r['complex_halves'].values()
                                for o in p['observations'])
                        and not any(o['strict_obstruction'] for o in r['full'])
                        for r in record['records'])
        print(json.dumps(dict(entry=entry, raw=record['raw_words'],
                              admissible=record['admissible_words'],
                              survivors_at_tested_parameters=survivors)), flush=True)
    destination = Path(__file__).with_suffix('.json')
    destination.write_text(json.dumps(dict(
        status='exact_finite_family_tests_no_realization_claim',
        geometry_is_separate=True, slopes=[1, 4, 25], records=result,
        entry_four_disk_covers=entry_four_disk_covers()), indent=2) + '\n')
