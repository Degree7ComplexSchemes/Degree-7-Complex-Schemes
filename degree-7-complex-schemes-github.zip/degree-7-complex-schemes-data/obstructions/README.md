# Archival obstruction data and code

These files preserve available computations relevant to the obstruction
sections. They supplement the freshly replayed census/separation data;
they are **not** executed by `python reproduce.py all` and are not a claim
that every obstruction calculation is now independently reproducible.

## Entry 2: coverings and exact inertia

`entry2/` retains the historical directory structure of the available
proof bundle, excluding the compiled PDF. It includes:

- Exact base and covering braid words.
- Seifert matrices and exact Hermitian elimination/inertia records.
- The 448-raw-word / 24-admissible-word family enumeration.
- Covering and sparse-elimination Python sources and tests.
- The contemporaneous proof-source snapshot.

The archived scripts distinguish finite algebra checks from the geometric
pencil-exhaustion arguments. Preserve that distinction. Their historical
source hashes may identify published PDFs not redistributed in this release.

## Floer fusion receipts

`floer/receipts/` contains the available entry-1 base/variant receipts.
The JSON records include selected saddle steps, Artin braid words, planar
diagram codes, ranks, tau values and the reported genus comparison.
The generating and chain-checking script snapshots are in `floer/scripts/`;
the available pencil helper is in `floer/tmp/`.

These optional scripts were written for the original larger project and
its knot-theory environment. The paper reports `knot_floer_homology` 1.2.2
and Spherogram 2.4.1. Those third-party runtimes are not vendored here, and
their full environment is not installed or validated by the portable runner.
Some scripts reference additional historical project paths. The JSON data
can be inspected independently; running the entire original campaign still
requires the corresponding environment and dependency audit.

The current manuscript's explicit outstanding reproducibility annotations
remain authoritative; see `../docs/manuscript-open-items.json`.

## Fresh entry-17 algebra and still missing colored input

`../scripts/replay_entry17.py` and `../expected/entry17-exact.json` provide
the complete fourteen-word ordinary-signature table, using the shared exact
Seifert builder and two independent elimination methods. The root `entry17`
command replays it. This addition does not prove geometric pencil exhaustion.

The indexed colored C-complex/matrix certificate for the specific W_plus and
(-8,0) in the proposed row-166 argument remains missing (query Q7). The
existing Floer summary is a conditional screen, not a whole-scheme exclusion.
The full list of prioritized obligations is `../docs/REFEREE_CHECKLIST.md`.
