"""Exploratory cyclic lifts; not a proof of geometric pencil exhaustion."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scripts.audit_table19_entry2_cover import (
    annular_rewrite, inverse, pencil_braid, reduce_word, seifert_matrix, tau,
)


def commuting_reduce(word):
    result = []
    for x in word:
        for j in range(len(result) - 1, -1, -1):
            if abs(abs(result[j]) - abs(x)) <= 1:
                if result[j] == -x:
                    result.pop(j)
                else:
                    result.append(x)
                break
        else:
            result.append(x)
    return result


def cyclic_lift(annular, degree, outer=6):
    strands = outer * degree + 1
    images = {i: [outer - i + 1 + j * outer for j in range(degree)]
              for i in range(1, outer)}
    block_word = [x for i in range(1, outer)
                  for x in [i + 1 + j * outer for j in range(degree)]]
    epsilon = [1] + list(range(1, strands))
    images[outer + 1] = commuting_reduce(epsilon + inverse(block_word))
    word = []
    for x in annular:
        word.extend(images[abs(x)] if x > 0 else inverse(images[abs(x)]))
    return commuting_reduce(word), strands


def step(position, word):
    for x in word:
        i = abs(x)
        if position == i:
            position = i + 1
        elif position == i + 1:
            position = i
    return position


def oval_signs(bands):
    marked, j = 3, 5
    initial = [-2] + tau(2, bands[0])
    marked, j = step(marked, initial), step(j, initial)
    result = []
    for k, l in zip(bands, bands[1:] + [5]):
        if marked not in (k, k + 1) or j in (k, k + 1):
            return None
        result.append(marked == k + 1 if j > k + 1 else marked == k)
        event = [-k] + tau(k, l)
        marked, j = step(marked, event), step(j, event)
    return result


def candidates():
    from itertools import combinations, product
    for positions in combinations(range(8), 3):
        for bands in product((3, 4), repeat=3):
            word = [2] * 8
            for p, k in zip(positions, bands):
                word[p] = k
            signs = oval_signs(word)
            if (signs is not None and not any(signs[p] for p in positions)
                    and sum(signs[p] for p in range(8) if p not in positions) == 3):
                yield word


def family():
    import numpy as np
    for bands in candidates():
        annular = annular_rewrite(pencil_braid(bands))[0]
        records = []
        for degree in (2, 4):
            word, strands = cyclic_lift(annular, degree)
            v = np.array(seifert_matrix(word, strands), dtype=float)
            values = []
            for slope in (4, 13, 25):
                eig = np.linalg.eigvalsh(slope * (v + v.T) + 1j * (v.T - v))
                sig = int(sum(eig > 1e-7) - sum(eig < -1e-7))
                nul = 1 + int(sum(abs(eig) <= 1e-7))
                values.append((abs(sig) - nul, slope, sig, nul))
            records.append((degree, max(values)))
        print(bands, records, flush=True)


def main():
    import numpy as np
    base = annular_rewrite(pencil_braid([3, 4, 3] + [2] * 5))[0]
    for degree in range(2, 7):
        word, strands = cyclic_lift(base, degree)
        v = np.array(seifert_matrix(word, strands), dtype=float)
        values = []
        for theta in np.linspace(.025, .475, 19):
            z = np.exp(2j * np.pi * theta)
            eig = np.linalg.eigvalsh((1 - z) * v + (1 - z.conjugate()) * v.T)
            sig = int(sum(eig > 1e-7) - sum(eig < -1e-7))
            nul = 1 + int(sum(abs(eig) <= 1e-7))
            values.append((abs(sig) - nul, round(float(theta), 4), sig, nul))
        print(degree, len(v), "bound", 6 * degree - 1, "sampled max", max(values), flush=True)


if __name__ == "__main__":
    family() if "family" in sys.argv else main()
