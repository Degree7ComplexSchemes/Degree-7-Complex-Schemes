import random
import unittest
import json
from pathlib import Path

from scripts.audit_table19_entry2_cover import (
    annular_rewrite, artin_action, audit, covering_braid, gaussian_inertia,
    integer_inertia, inverse, pencil_braid, rational_inertia, reduce_word,
    realification, seifert_matrix,
)
from scripts.entry2_sparse_inertia import sparse_inertia
from scripts.audit_table19_entry2_family import (
    enumerate_family, exact_record, lift_once, orientation_ledger,
)


class Entry2CoverTests(unittest.TestCase):
    def assert_braids_equal(self, left, right, strands):
        self.assertEqual(artin_action(left, strands), artin_action(right, strands))

    def test_artin_relations(self):
        for i in range(1, 6):
            self.assert_braids_equal([i, i + 1, i], [i + 1, i, i + 1], 7)
        for i in range(1, 7):
            self.assert_braids_equal([i, -i], [], 7)
            for j in range(i + 2, 7):
                self.assert_braids_equal([i, j], [j, i], 7)

    def test_covering_homomorphism_relations(self):
        lift = covering_braid
        for i in range(1, 5):
            self.assert_braids_equal(lift([i, i + 1, i]),
                                     lift([i + 1, i, i + 1]), 13)
            self.assert_braids_equal(lift([i, 7]), lift([7, i]), 13)
        self.assert_braids_equal(lift([5, 7, 5, 7]), lift([7, 5, 7, 5]), 13)
        for i in range(1, 6):
            self.assert_braids_equal(lift([i, -i]), [], 13)
        self.assert_braids_equal(lift([7, -7]), [], 13)

    def test_annular_rewrite_controls(self):
        rng = random.Random(1937)
        transport = [3, 4, 5, 6]
        for _ in range(20):
            annular = [rng.choice([-7, -5, -4, -3, -2, -1, 1, 2, 3, 4, 5, 7])
                       for _ in range(8)]
            expanded = []
            for x in annular:
                expanded.extend([6 if x > 0 else -6] * 2 if abs(x) == 7 else [x])
            original = transport + expanded + inverse(transport)
            recovered, _ = annular_rewrite(original)
            self.assertEqual(recovered, reduce_word(annular))

    def test_published_seifert_matrices(self):
        self.assertEqual(seifert_matrix([1, 1, 1], 2), [[-1, 1], [0, -1]])
        v = seifert_matrix([2, -1, 2, 2, 1], 3)
        order = [1, 2, 0]
        self.assertEqual([[v[i][j] for j in order] for i in order],
                         [[-1, 1, 0], [0, -1, 0], [1, 0, 0]])

    def test_seifert_invariance_controls(self):
        controls = [([1, 1, 1], 2), ([1, 1, 1, 2], 3),
                    ([2, 1, 1, 1, 2, -2], 3)]
        for word, strands in controls:
            pos, neg, zero = gaussian_inertia(seifert_matrix(word, strands))[0]
            self.assertEqual((pos - neg, zero), (-2, 0))

    def test_published_c7_signature_at_i(self):
        # Section 2 of c7.pdf, including its adjusted-nullity convention.
        for prefix in ([3, 3, 4], [4, 3, 3]):
            word = pencil_braid(prefix + [2] * 9)
            v = seifert_matrix(word, 7)
            pos, neg, zero = integer_inertia(realification(v, slope=1))[0]
            self.assertEqual(((pos - neg) // 2, 1 + zero // 2), (-3, 2))
            self.assertEqual(sum(1 if x > 0 else -1 for x in word), 8)

    def test_integer_against_fraction_elimination(self):
        rng = random.Random(719)
        matrices = [[[0, 1], [1, 0]], [[0, 0], [0, 0]], [[-1, 0], [0, 1]]]
        for n in range(1, 9):
            for _ in range(12):
                a = [[0] * n for _ in range(n)]
                for i in range(n):
                    for j in range(i, n):
                        a[i][j] = a[j][i] = rng.randrange(-5, 6)
                matrices.append(a)
        for a in matrices:
            self.assertEqual(integer_inertia(a)[0], rational_inertia(a))

    def test_entry2_exact_receipts(self):
        for surgery, expected in [(False, (134, 158, 0)), (True, (136, 160, 0))]:
            record = audit([3, 4, 3] + [2] * 5, surgery)
            self.assertEqual(record["realified_inertia"], expected)
            self.assertEqual((record["signature"], record["adjusted_nullity"]), (-12, 1))
            self.assertTrue(record["artin_action_verified"])
            self.assertTrue(record["independent_exact_inertia_verified"])
            self.assertEqual(record["base_exponent"], 11 if surgery else 12)
            word = pencil_braid([3, 4, 3] + [2] * 5, surgery)
            permutation = list(range(1, 8))
            for x in word:
                k = abs(x) - 1
                permutation[k], permutation[k + 1] = permutation[k + 1], permutation[k]
            self.assertEqual(permutation[2], 3)

    def test_sparse_against_both_dense_exact_algorithms(self):
        rng = random.Random(193704)
        matrices = [[[0, 1], [-1, 0]], [[0, 1], [0, 0]], [[0, 0], [0, 0]]]
        for n in range(1, 10):
            for _ in range(12):
                matrices.append([[rng.randrange(-3, 4) for _ in range(n)]
                                 for _ in range(n)])
        for v in matrices:
            for slope in (1, 4, 25, 100):
                expected = sparse_inertia(v, slope)[0]
                self.assertEqual(gaussian_inertia(v, slope)[0], expected)
                self.assertEqual(integer_inertia(realification(v, slope))[0],
                                 tuple(2 * x for x in expected))

    def test_family_enumeration_and_marking(self):
        raw, family = enumerate_family()
        self.assertEqual(len(raw), 448)
        self.assertEqual(len({tuple(row["bands"]) for row in raw}), 448)
        self.assertEqual(len(family), 24)
        for row in raw:
            ledger = row["orientation_ledger"]
            self.assertIsNotNone(ledger)
            for index, entry in enumerate(ledger, 1):
                band = entry["band"]
                self.assertEqual(entry["positive_sheet_position"],
                                 band if index % 2 else band + 1)
                self.assertEqual(entry["odd_branch_position"], 5 if band <= 3 else 3)
                self.assertEqual(entry["positive_oval"],
                                 (index % 2 == 0) if band <= 3 else (index % 2 == 1))
        for bands in family:
            ledger = orientation_ledger(bands)
            self.assertEqual(sum(x["positive_oval"] for x in ledger), 3)
            self.assertFalse(any(x["positive_oval"] for x in ledger if x["band"] != 2))
            word = pencil_braid(bands)
            self.assertEqual(position_after_for_test(3, word), 3)
            self.assertEqual(position_after_for_test(5, word), 5)
        # Published orientation patterns in c7.pdf, Section 2.
        for prefix, signs in [([3, 3, 4], [False, True, True]),
                              ([4, 3, 3], [True, True, False])]:
            ledger = orientation_ledger(prefix + [2] * 9)
            self.assertEqual([x["positive_oval"] for x in ledger[:3]], signs)
            self.assertEqual(sum(x["positive_oval"] for x in ledger[3:]), 5)

    def test_all_iterated_cover_receipts(self):
        path = Path(__file__).resolve().parents[1] / "output/table19_entry2_family_exact.json"
        certificate = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(certificate["raw_word_count"], 448)
        self.assertEqual(certificate["admissible_word_count"], 24)
        family = enumerate_family()[1]
        self.assertEqual([r["bands"] for r in certificate["records"]], family)
        degrees = []
        for saved in certificate["records"]:
            replayed = exact_record(saved["bands"])
            # Convert tuple-valued Python results to their JSON representation.
            self.assertEqual(json.loads(json.dumps(replayed)), saved)
            self.assertEqual(saved["adjusted_nullity"], 1)
            self.assertGreater(abs(saved["signature"]) - 1, saved["surface_bound"])
            for level, layer in enumerate(saved["cover_layers"], 1):
                self.assertEqual(sum(1 if x > 0 else -1
                                     for x in layer["covering_braid"]), 12 * 2 ** level)
            degrees.append(saved["cover_degree"])
        self.assertEqual((degrees.count(4), degrees.count(8)), (15, 9))

    def test_fourth_cover_independent_dense_control(self):
        path = Path(__file__).resolve().parents[1] / "output/table19_entry2_iterated_cover_exact.json"
        certificate = json.loads(path.read_text(encoding="utf-8"))
        v = certificate["seifert_matrix"]
        expected = (227, 255, 0)
        self.assertEqual(gaussian_inertia(v, 25)[0], expected)
        self.assertEqual(sparse_inertia(v, 25)[0], expected)

    def test_realizable_scheme_equality_control(self):
        # The signs match Brugalle's realizable M-scheme J + 2_- + O_-(7_+,5_-).
        # This word is an equality control, not a claimed construction of its pencil.
        bands = [3, 2, 3] + [2] * 9
        ledger = orientation_ledger(bands)
        self.assertEqual(sum(x["positive_oval"] for x in ledger if x["band"] == 2), 6)
        self.assertFalse(any(x["positive_oval"] for x in ledger if x["band"] != 2))
        word, strands, branch = pencil_braid(bands), 7, 3
        for degree, slope in [(2, 4), (4, 25), (8, 100)]:
            word, _ = lift_once(word, strands, branch)
            branch, strands = strands, 2 * strands - 1
            inertia = sparse_inertia(seifert_matrix(word, strands), slope)[0]
            self.assertEqual((inertia[0] - inertia[1], 1 + inertia[2]), (-2 * degree, 1))


def position_after_for_test(position, word):
    labels = list(range(1, 8))
    for generator in word:
        i = abs(generator) - 1
        labels[i:i + 2] = reversed(labels[i:i + 2])
    return labels.index(position) + 1


if __name__ == "__main__":
    unittest.main()
