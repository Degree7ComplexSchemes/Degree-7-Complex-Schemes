"""Exact iterated-double-cover obstruction for a submitted pencil only."""
from pathlib import Path
import hashlib
import json
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scripts.audit_table19_entry2_cover import (
    annular_rewrite, covering_braid, gaussian_inertia, pencil_braid,
    seifert_matrix,
)


def build(bands):
    base = pencil_braid(bands)
    first_annular, first_conjugate = annular_rewrite(base)
    first = covering_braid(first_annular)
    second_annular, second_conjugate = annular_rewrite(first, strands=13, branch=7)
    second = covering_braid(second_annular, strands=13)
    return {
        "bands": bands, "base_braid": base,
        "first_conjugated_braid": first_conjugate,
        "first_annular_braid": first_annular, "first_covering_braid": first,
        "second_conjugated_braid": second_conjugate,
        "second_annular_braid": second_annular, "second_covering_braid": second,
        "both_artin_action_checks_passed": True,
        "seifert_matrix": seifert_matrix(second, 25),
    }


def main():
    start = time.monotonic()
    result = build([3, 4, 3] + [2] * 5)
    v = result["seifert_matrix"]
    print("Verified both covering rewrites; matrix size", len(v), flush=True)
    def progress(done, total):
        print("Exact Hermitian elimination", done, "/", total,
              "elapsed", round(time.monotonic() - start, 1), flush=True)
    inertia, pivots = gaussian_inertia(v, slope=25, progress=progress)
    result.update({
        "zeta": {"real": [-312, 313], "imaginary": [25, 313]},
        "hermitian_inertia": inertia,
        "signature": inertia[0] - inertia[1], "adjusted_nullity": 1 + inertia[2],
        "elimination_pivots": pivots, "slope": 25,
        "surface_euler_characteristic": -23,
        "seifert_matrix_size": len(v),
        "geometric_pencil_exhaustion_proved": False,
        "jump_cases_excluded": False, "scheme_nonrealizability_proved": False,
        "vanishing_cycle_used": False,
        "status": "exact_iterated_cover_obstruction_for_submitted_pencil",
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "support_script_sha256": hashlib.sha256(Path(__file__).with_name("audit_table19_entry2_cover.py").read_bytes()).hexdigest(),
    })
    destination = Path(__file__).resolve().parents[1] / "output/table19_entry2_iterated_cover_exact.json"
    destination.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: result[k] for k in ("hermitian_inertia", "signature", "adjusted_nullity", "surface_euler_characteristic", "status")}), flush=True)


if __name__ == "__main__":
    main()
