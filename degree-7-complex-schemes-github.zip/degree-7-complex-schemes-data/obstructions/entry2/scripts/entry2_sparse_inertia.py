"""Exact sparse Hermitian Schur elimination, independent of Bareiss elimination."""
from math import gcd


ZERO = (0, 0, 1)


def normalize(real, imag, denominator=1):
    if denominator < 0:
        real, imag, denominator = -real, -imag, -denominator
    divisor = gcd(gcd(real, imag), denominator)
    return real // divisor, imag // divisor, denominator // divisor


def add(a, b):
    common = gcd(a[2], b[2])
    left, right = b[2] // common, a[2] // common
    return normalize(a[0] * left + b[0] * right,
                     a[1] * left + b[1] * right, a[2] * left)


def conjugate(a):
    return a[0], -a[1], a[2]


def imaginary_multiple(a):
    return -a[1], a[0], a[2]


def negative_product_over_pivot(b, c, pivot):
    # -b*conjugate(c)/pivot; the pivot is a nonzero real rational number.
    return normalize(-(b[0] * c[0] + b[1] * c[1]) * pivot[2],
                     -(b[1] * c[0] - b[0] * c[1]) * pivot[2],
                     b[2] * c[2] * pivot[0])


def sparse_inertia(v, slope=4, progress=None):
    n = len(v)
    rows = [{} for _ in range(n)]
    for i in range(n):
        for j in range(n):
            value = (slope * (v[i][j] + v[j][i]), v[j][i] - v[i][j], 1)
            if value != ZERO:
                rows[i][j] = value
    live = set(range(n))
    counts = [0, 0, 0]
    receipts = []

    def put(i, j, value):
        if value == ZERO:
            rows[i].pop(j, None)
            rows[j].pop(i, None)
        else:
            rows[i][j] = value
            rows[j][i] = conjugate(value)

    while live:
        isolated = [i for i in live if not rows[i]]
        for i in isolated:
            live.remove(i)
            counts[2] += 1
            receipts.append({"index": i, "zero": True})
        if not live:
            break
        choices = [i for i in live if i in rows[i]]
        shear = None
        if not choices:
            i = min(live)
            j = min(rows[i])
            edge = rows[i][j]
            imaginary = edge[0] == 0
            ri, rj = dict(rows[i]), dict(rows[j])
            for l in sorted((set(ri) | set(rj)) - {i}):
                other = rj.get(l, ZERO)
                if imaginary:
                    other = imaginary_multiple(other)
                put(i, l, add(ri.get(l, ZERO), other))
            put(i, i, normalize(2 * edge[1 if imaginary else 0], 0, edge[2]))
            choices = [i]
            shear = {"other": j, "imaginary": imaginary}
        k = min(choices, key=lambda i: (len(rows[i]), i))
        pivot = rows[k][k]
        if pivot[1] or not pivot[0]:
            raise ArithmeticError("Invalid real Hermitian pivot")
        counts[0 if pivot[0] > 0 else 1] += 1
        receipts.append({"index": k, "numerator": str(pivot[0]),
                         "denominator": str(pivot[2]), "shear": shear})
        neighbors = sorted(set(rows[k]) - {k})
        column = {i: rows[i][k] for i in neighbors}
        for p, i in enumerate(neighbors):
            for j in neighbors[p:]:
                value = add(rows[i].get(j, ZERO),
                            negative_product_over_pivot(column[i], column[j], pivot))
                put(i, j, value)
        for i in neighbors:
            del rows[i][k]
        rows[k].clear()
        live.remove(k)
        if progress is not None and (len(receipts) % 64 == 0 or not live):
            progress(len(receipts), n)
    return tuple(counts), receipts
