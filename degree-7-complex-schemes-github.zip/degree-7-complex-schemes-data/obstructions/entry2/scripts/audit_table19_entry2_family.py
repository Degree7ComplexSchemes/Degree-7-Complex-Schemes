"""Exhaust and certify a precisely specified marked pencil-word family.

The script certifies the finite braid calculation. The geometric reduction to
this family is a mathematical argument in docs/table19_entry2_proof.tex, not a
property established by running this program.
"""
from itertools import combinations, product
from pathlib import Path
import hashlib
import json
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scripts.audit_table19_entry2_cover import (
    annular_rewrite, covering_braid, pencil_braid, seifert_matrix, tau,
)
from scripts.entry2_sparse_inertia import sparse_inertia


def position_after(position, word):
    for x in word:
        i = abs(x)
        if position == i:
            position += 1
        elif position == i + 1:
            position -= 1
    return position


def orientation_ledger(bands):
    marked, odd = 3, 5
    event = [-2] + tau(2, bands[0])
    marked = position_after(marked, event)
    odd = position_after(odd, event)
    ledger = []
    for k, next_band in zip(bands, bands[1:] + [5]):
        if marked not in (k, k + 1) or odd in (k, k + 1):
            return None
        positive = marked == (k + 1 if odd > k + 1 else k)
        ledger.append({"band": k, "positive_sheet_position": marked,
                       "odd_branch_position": odd, "positive_oval": positive})
        event = [-k] + tau(k, next_band)
        marked = position_after(marked, event)
        odd = position_after(odd, event)
    return ledger


def enumerate_family():
    all_words, accepted = [], []
    for outer_positions in combinations(range(8), 3):
        for outer_bands in product((3, 4), repeat=3):
            bands = [2] * 8
            for position, band in zip(outer_positions, outer_bands):
                bands[position] = band
            ledger = orientation_ledger(bands)
            matches = (ledger is not None
                       and not any(ledger[p]["positive_oval"] for p in outer_positions)
                       and sum(ledger[p]["positive_oval"] for p in range(8)
                               if p not in outer_positions) == 3)
            all_words.append({"bands": bands, "orientation_ledger": ledger,
                              "matches_target_signs": matches})
            if matches:
                accepted.append(bands)
    return all_words, accepted


def lift_once(word, strands, branch):
    annular, conjugate = annular_rewrite(word, strands, branch)
    lifted = covering_braid(annular, strands)
    return lifted, {"input_strands": strands, "input_branch": branch,
                    "conjugated_braid": conjugate, "annular_braid": annular,
                    "covering_braid": lifted, "artin_action_verified": True}


def exact_record(bands):
    word = pencil_braid(bands)
    base, layers = list(word), []
    strands, branch = 7, 3
    for _ in range(2):
        word, layer = lift_once(word, strands, branch)
        layers.append(layer)
        branch, strands = strands, 2 * strands - 1
    v = seifert_matrix(word, strands)
    inertia, pivots = sparse_inertia(v, slope=25)
    degree, slope = 4, 25
    fourth_check = {"inertia": inertia, "signature": inertia[0] - inertia[1],
                    "adjusted_nullity": 1 + inertia[2], "slope": slope,
                    "matrix_size": len(v)}
    if abs(inertia[0] - inertia[1]) - (1 + inertia[2]) <= 23:
        word, layer = lift_once(word, strands, branch)
        layers.append(layer)
        branch, strands = strands, 2 * strands - 1
        v = seifert_matrix(word, strands)
        inertia, pivots = sparse_inertia(v, slope=100)
        degree, slope = 8, 100
    signature, nullity = inertia[0] - inertia[1], 1 + inertia[2]
    bound = 6 * degree - 1
    if abs(signature) - nullity <= bound:
        raise ArithmeticError("Candidate is not excluded by the specified cover")
    # Store sparse V without discarding any nonzero entry.
    entries = [[i, j, value] for i, row in enumerate(v)
               for j, value in enumerate(row) if value]
    return {"bands": bands, "orientation_ledger": orientation_ledger(bands),
            "base_braid": base, "cover_layers": layers, "cover_degree": degree,
            "strands": strands, "branch_position": branch, "slope": slope,
            "zeta": {"real": [1 - slope * slope, 1 + slope * slope],
                     "imaginary": [2 * slope, 1 + slope * slope]},
            "matrix_size": len(v), "seifert_matrix_nonzero_entries": entries,
            "hermitian_inertia": inertia, "signature": signature,
            "adjusted_nullity": nullity, "surface_bound": bound,
            "strict_obstruction": abs(signature) - nullity > bound,
            "rational_elimination_receipts": pivots, "fourth_cover_check": fourth_check}


def main():
    start = time.monotonic()
    all_words, family = enumerate_family()
    if len(all_words) != 448 or len(family) != 24:
        raise ArithmeticError("Unexpected finite-family count")
    records = []
    for bands in family:
        record = exact_record(bands)
        records.append(record)
        print(json.dumps({k: record[k] for k in (
            "bands", "cover_degree", "matrix_size", "hermitian_inertia",
            "signature", "adjusted_nullity", "surface_bound")}),
            "elapsed", round(time.monotonic() - start, 1), flush=True)
    root = Path(__file__).resolve().parents[1]
    scripts = [Path(__file__), root / "scripts/audit_table19_entry2_cover.py",
               root / "scripts/entry2_sparse_inertia.py"]
    result = {"status": "exact_obstruction_of_entire_specified_marked_pencil_family",
              "raw_word_count": len(all_words), "admissible_word_count": len(family),
              "enumeration": all_words, "records": records,
              "vanishing_cycle_used": False,
              "numerical_eigenvalues_used": False,
              "geometric_reduction_is_a_separate_proof": True,
              "script_hashes": {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                                for p in scripts},
              "source_hashes": {name: hashlib.sha256(
                  Path("C:/Users/brenn/Downloads", name).read_bytes()).hexdigest()
                  for name in ("main (24).pdf", "c7.pdf", "top.pdf", "Symmetric7.pdf")}}
    destination = root / "output/table19_entry2_family_exact.json"
    destination.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("Certified all 24 marked words.", flush=True)


if __name__ == "__main__":
    main()
