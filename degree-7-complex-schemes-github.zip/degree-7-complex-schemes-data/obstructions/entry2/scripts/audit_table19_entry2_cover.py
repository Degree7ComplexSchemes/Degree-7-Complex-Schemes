"""Exact algebra for a candidate pencil, without a geometric exhaustion claim.

The covering homomorphism is Orevkov, Link theory and oval arrangements,
Section 2.7. Integer words use signed one-based Artin generators.
"""
from fractions import Fraction
import hashlib
import json
from pathlib import Path


def inverse(word):
    return [-x for x in reversed(word)]


def reduce_word(word):
    result = []
    for x in word:
        if result and result[-1] == -x:
            result.pop()
        else:
            result.append(x)
    return result


def artin_action(word, strands):
    images = [[i] for i in range(1, strands + 1)]
    for generator in word:
        k = abs(generator) - 1
        a, b = images[k:k + 2]
        if generator > 0:
            images[k:k + 2] = [reduce_word(a + b + inverse(a)), a]
        else:
            images[k:k + 2] = [b, reduce_word(inverse(b) + a + b)]
    return images


def tau(k, l):
    if k < l:
        return list(range(-(k + 1), -l - 1, -1)) + list(range(k, l))
    if k > l:
        return list(range(-(k - 1), -l + 1)) + list(range(k, l, -1))
    return []


def pencil_braid(bands, surgery=False):
    result = [-1] if surgery else []
    path = (2,) + tuple(bands) + (5,)
    for k, l in zip(path, path[1:]):
        result.extend([-k] + tau(k, l))
    for last in range(6, 0, -1):
        result.extend(range(1, last + 1))
    return result


def annular_rewrite(word, strands=7, branch=3):
    """Move the marked strand right and rewrite in B_(m-1) and sigma_(m-1)^2."""
    transport = list(range(branch, strands))
    conjugate = inverse(transport) + list(word) + transport
    position = strands
    annular = []
    for generator in conjugate:
        i, sign = abs(generator), 1 if generator > 0 else -1
        if i < position - 1:
            annular.append(sign * i)
        elif i > position:
            annular.append(sign * (i - 1))
        else:
            loop = None
            if i == position:
                if sign < 0:
                    loop = (i, -1)
                position += 1
            else:
                if sign > 0:
                    loop = (i, 1)
                position -= 1
            if loop is not None:
                j, epsilon = loop
                along = list(range(j, strands - 1))
                annular.extend(along + [epsilon * strands] + inverse(along))
    if position != strands:
        raise ValueError("Marked strand is not a closed component")
    # The special letter +/-m denotes the loop sigma_(m-1)^(+/-2).
    expanded = []
    for x in annular:
        expanded.extend([((strands - 1) if x > 0 else -(strands - 1))] * 2
                        if abs(x) == strands else [x])
    if artin_action(expanded, strands) != artin_action(conjugate, strands):
        raise ArithmeticError("Annular rewrite fails the faithful Artin action")
    return reduce_word(annular), conjugate


def covering_braid(annular, strands=7):
    result = []
    for x in annular:
        i, sign = abs(x), 1 if x > 0 else -1
        if i == strands:
            result.extend(sign * j for j in (strands, strands - 1, strands))
        else:
            result.extend((sign * i, sign * (2 * strands - i - 1)))
    return reduce_word(result)


def seifert_matrix(word, strands):
    if set(map(abs, word)) != set(range(1, strands)):
        raise ValueError("The standard Seifert surface is not connected")
    loops = []
    for index in range(1, strands):
        positions = [p for p, value in enumerate(word) if abs(value) == index]
        loops.extend((index, p, q) for p, q in zip(positions, positions[1:]))
    result = [[0] * len(loops) for _ in loops]
    sign = lambda p: 1 if word[p] > 0 else -1
    for row, (i, p, q) in enumerate(loops):
        for col, (j, r, s) in enumerate(loops):
            if row == col:
                result[row][col] = -(sign(p) + sign(q)) // 2
            elif i == j and q == r:
                result[row][col] = (sign(q) + 1) // 2
            elif i == j and s == p:
                result[row][col] = (sign(p) - 1) // 2
            elif j == i + 1 and p < r < q < s:
                result[row][col] = -1
            elif j == i + 1 and r < p < s < q:
                result[row][col] = 1
    return result


def integer_inertia(symmetric):
    a = [list(row) for row in symmetric]
    denominator = 1
    positive = negative = 0
    pivots = []
    while a:
        k = next((j for j in range(len(a)) if a[j][j]), None)
        shear = None
        if k is None:
            edge = next(((i, j) for i in range(len(a)) for j in range(i + 1, len(a)) if a[i][j]), None)
            if edge is None:
                return (positive, negative, len(a)), pivots
            i, j = edge
            a[i] = [x + y for x, y in zip(a[i], a[j])]
            for row in a:
                row[i] += row[j]
            k, shear = i, edge
        pivot = a[k][k]
        positive += pivot * denominator > 0
        negative += pivot * denominator < 0
        pivots.append({"index": k, "shear": shear, "numerator": str(pivot), "denominator": str(denominator)})
        indices = [j for j in range(len(a)) if j != k]
        result = [[0] * len(indices) for _ in indices]
        for p, i in enumerate(indices):
            for q in range(p, len(indices)):
                j = indices[q]
                value, remainder = divmod(pivot * a[i][j] - a[i][k] * a[k][j], denominator)
                if remainder:
                    raise ArithmeticError("Nonintegral fraction-free elimination")
                result[p][q] = result[q][p] = value
        a, denominator = result, pivot
    return (positive, negative, 0), pivots


def rational_inertia(matrix):
    """Independent rational elimination for small matrices used as controls."""
    a = [[Fraction(x) for x in row] for row in matrix]
    positive = negative = 0
    while a:
        k = next((j for j in range(len(a)) if a[j][j]), None)
        if k is None:
            edge = next(((i, j) for i in range(len(a)) for j in range(i + 1, len(a)) if a[i][j]), None)
            if edge is None:
                return positive, negative, len(a)
            i, j = edge
            a[i] = [x + y for x, y in zip(a[i], a[j])]
            for row in a:
                row[i] += row[j]
            k = i
        pivot = a[k][k]
        positive += pivot > 0
        negative += pivot < 0
        indices = [j for j in range(len(a)) if j != k]
        a = [[a[i][j] - a[i][k] * a[k][j] / pivot for j in indices] for i in indices]
    return positive, negative, 0


def realification(v, slope=4):
    n = len(v)
    s = [[slope * (v[i][j] + v[j][i]) for j in range(n)] for i in range(n)]
    a = [[v[j][i] - v[i][j] for j in range(n)] for i in range(n)]
    return ([s[i] + [-x for x in a[i]] for i in range(n)]
            + [a[i] + s[i] for i in range(n)])


def gaussian_inertia(v, slope=4, progress=None):
    """Fraction-free Hermitian elimination over Gaussian integers, not R^(2n)."""
    a = [[(slope * (v[i][j] + v[j][i]), v[j][i] - v[i][j])
          for j in range(len(v))] for i in range(len(v))]
    denominator = 1
    positive = negative = 0
    pivots = []
    while a:
        k = next((j for j in range(len(a)) if a[j][j][0]), None)
        if k is None:
            edge = next(((i, j) for i in range(len(a)) for j in range(i + 1, len(a))
                         if a[i][j] != (0, 0)), None)
            if edge is None:
                return (positive, negative, len(a)), pivots
            i, j = edge
            imaginary_shear = not a[i][j][0]
            if imaginary_shear:
                a[i] = [(x - w, y + u) for (x, y), (u, w) in zip(a[i], a[j])]
                for row in a:
                    x, y = row[i]
                    u, w = row[j]
                    row[i] = (x + w, y - u)
            else:
                a[i] = [(x + u, y + w) for (x, y), (u, w) in zip(a[i], a[j])]
                for row in a:
                    x, y = row[i]
                    u, w = row[j]
                    row[i] = (x + u, y + w)
            k = i
        pivot, imaginary = a[k][k]
        if imaginary:
            raise ArithmeticError("A Hermitian diagonal must be real")
        positive += pivot * denominator > 0
        negative += pivot * denominator < 0
        pivots.append({"index": k, "numerator": str(pivot),
                       "denominator": str(denominator)})
        indices = [j for j in range(len(a)) if j != k]
        result = [[(0, 0)] * len(indices) for _ in indices]
        for p, i in enumerate(indices):
            x, y = a[i][k]
            for q in range(p, len(indices)):
                j = indices[q]
                u, w = a[k][j]
                real, imag = a[i][j]
                real, remainder_r = divmod(pivot * real - x * u + y * w, denominator)
                imag, remainder_i = divmod(pivot * imag - x * w - y * u, denominator)
                if remainder_r or remainder_i:
                    raise ArithmeticError("Nonintegral Gaussian elimination")
                result[p][q], result[q][p] = (real, imag), (real, -imag)
        a, denominator = result, pivot
        if progress is not None and (len(pivots) % 32 == 0 or not a):
            progress(len(pivots), len(v))
    return (positive, negative, 0), pivots


def audit(bands, surgery=False):
    original = pencil_braid(bands, surgery)
    annular, conjugate = annular_rewrite(original)
    lifted = covering_braid(annular)
    v = seifert_matrix(lifted, 13)
    inertia, pivots = integer_inertia(realification(v))
    hermitian_inertia, hermitian_pivots = gaussian_inertia(v)
    if inertia != tuple(2 * x for x in hermitian_inertia):
        raise ArithmeticError("The two exact inertia calculations disagree")
    signature, nullity = (inertia[0] - inertia[1]) // 2, 1 + inertia[2] // 2
    classical, _ = integer_inertia([[v[i][j] + v[j][i] for j in range(len(v))]
                                   for i in range(len(v))])
    return {
        "bands": bands, "surgery": surgery, "base_braid": original,
        "conjugated_braid": conjugate, "annular_braid": annular,
        "covering_braid": lifted, "artin_action_verified": True,
        "base_exponent": sum(1 if x > 0 else -1 for x in original),
        "covering_exponent": sum(1 if x > 0 else -1 for x in lifted),
        "seifert_matrix_size": len(v), "seifert_matrix": v,
        "realified_inertia": inertia, "signature": signature,
        "adjusted_nullity": nullity, "elimination_pivots": pivots,
        "hermitian_inertia": hermitian_inertia,
        "gaussian_elimination_pivots": hermitian_pivots,
        "independent_exact_inertia_verified": True,
        "classical_signature": classical[0] - classical[1],
        "classical_adjusted_nullity": 1 + classical[2],
        "status": "exact_covering_braid_and_signature_for_submitted_pencil",
    }


def main():
    records = []
    for surgery in (False, True):
        record = audit([3, 4, 3] + [2] * 5, surgery)
        records.append(record)
        print(json.dumps({k: record[k] for k in ("surgery", "base_exponent", "covering_exponent", "seifert_matrix_size", "realified_inertia", "signature", "adjusted_nullity", "status")}), flush=True)
    destination = Path(__file__).resolve().parents[1] / "output/table19_entry2_cover_exact.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    source = Path("C:/Users/brenn/Downloads/c7.pdf")
    result = {
        "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "covering_algorithm_source": "Orevkov, Link theory and oval arrangements, Sections 2.5 and 2.7",
        "source_hashes": {name: hashlib.sha256(Path("C:/Users/brenn/Downloads", name).read_bytes()).hexdigest()
                          for name in ("main (24).pdf", "top.pdf", "c7.pdf")},
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "zeta": {"real": [-15, 17], "imaginary": [8, 17]}, "records": records,
        "geometric_pencil_exhaustion_proved": False,
        "vanishing_half_disk_proved": False, "jump_cases_excluded": False,
        "scheme_nonrealizability_proved": False,
    }
    destination.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
