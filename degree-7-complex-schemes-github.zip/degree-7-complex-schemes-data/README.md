# Degree 7 Complex Schemes: data and reproducibility

Computational companion to Brennan Williams, *Degree 7 Complex Schemes*.
This directory is ready to become the contents of a GitHub repository.
Companion bundle version 1.1.0. Repository: https://github.com/Degree7ComplexSchemes/Degree-7-Complex-Schemes.
This ZIP updates the repository contents; it does not itself publish a tagged release or DOI.

The manuscript is `paper/main.tex`. Its two long Section 10 construction
tables have moved to `data/` and `exports/construction-tables.tex`.
The geometric argument and compact audit summary remain in the manuscript.

## Reproduce

Use Python 3.10 or later, without `-O`. All commands below use only the
Python standard library and require no network access or Sage installation.
Run them from this directory after extracting the ZIP:

```text
python -B reproduce.py validate
python -B reproduce.py census
python -B reproduce.py lower-bound
python -B reproduce.py paper-points
python -B reproduce.py screen
python -B reproduce.py bindings
python -B reproduce.py entry17
python -B reproduce.py paper
```

Or run all checks:

```text
python -B reproduce.py all
```

The full original audit and the paper-point audit each take several minutes;
the other commands are shorter. Every run writes to a new directory under
`results/` and preserves the shipped reports. To select a location, append
`--output-dir results/my-first-replay`; that directory must not already exist.
Read the per-stage logs there if a stage fails.

Large historical JSON inputs are stored as deterministic gzip files to keep
individual upload files small. The runner checks their hashes and restores
the exact original bytes locally before replay. These generated files and
`results/` are excluded by `.gitignore`. No input is downloaded.

## What the checks establish

| Command | Check |
|---|---|
| `validate` | Release hashes, original certificate hashes, CSV/JSON agreement, 103 heights and 1430 masks |
| `census` | 93 distinct type I complex schemes; 106 type II real schemes with nonzero syndromes and independently read nesting |
| `lower-bound` | Original whole-bank sphere geometry, exact signs, 103 strict liftings, and every one of the 19,494 within-group pairs |
| `paper-points` | Marked points reconstructed by the formula now printed in Section 10; all joint relations matched to the original and all within-group pairs checked |
| `screen` | Additional coordinate-permutation and sign-gauge false-positive screen |
| `bindings` | Reconstruct 13835 point certificates and list the 21 singleton scheme-only records |
| `entry17` | Recompute the 14 entry-17 matrices, pivots, determinants and exact inertia counts |
| `paper` | Check file citations, census rows, table transcription, margin queries and figure sources |

Expected lower-bound totals:

```text
families: 1430
type I / type II: 234 / 1196
point-bearing / coarse-only: 1409 / 21
strict integral liftings: 103
coarse groups: 199
pairs compared / isomorphic pairs: 19494 / 0
protected triples: 132137
A/B conics: 267780
additional C conics: 18165
total protected conics: 285945
```

The four additional classes in the manuscript come from its cited algebraic
constructions and Fiedler's jump distinction. They are not four extra rows
in the 1430-family patchworking inventory.

## Files

- `data/`: clean CSV and JSON construction data for Section 10.
- `census/`: separate portable 93/106-witness database, exact readers, scan
  inputs, C++17 discovery code, SQLite exports, and historical receipts.
- `vendor/septic_certificate_v2/`: original separation data and unchanged
  replay programs, with the historical directory structure preserved.
- `scripts/`: the current paper-point reconstruction and the type II wrapper.
- `obstructions/`: available covering/inertia data and Floer receipts with
  source snapshots; these archival supplements are not included in `all`.
- `expected/`: reference results, including the fresh checks made while
  preparing this manuscript revision.
- `exports/construction-tables.tex`: the exact removed table block.
- `plates/`: both final plate sets with triangulations, 199 vector panels, inputs, checks, and rendering sources.
- `docs/`: conventions, provenance, coverage, and remaining manuscript items.
- `MANIFEST.sha256.json`: SHA-256 digests of every distributed file except itself.

Read `docs/DATA_DICTIONARY.md` before converting masks: the earlier census
and the Section 10 inventory use opposite hexadecimal bit conventions.

## Final curve plates

`plates/pdf/` contains the final 93 dividing and 106 nondividing T-curve
plate sets, both with background triangulations. Individual vector panels,
exact inputs, rendering checks, original Viro/cloud sources, and portable
reassembly instructions are included in `plates/README.md`. Graphics
regeneration uses SageMath; assembling the supplied panels uses the optional
Python dependencies in `plates/requirements.txt`. These are separate from
the standard-library-only mathematical replay above.

## Scope

This package reproduces the witness censuses and the finite 1430-family
separation calculation under the manuscript's geometric arguments and cited
patchworking/orientation theorems. It does not formalize those theorems,
enumerate all septic chambers, or rerun the entire discovery history.

Some obstruction calculations elsewhere in the paper still have explicit
reproducibility gaps. These are listed in `docs/COVERAGE.md` and
`docs/manuscript-open-items.json`; packaging does not resolve them.
The available obstruction inputs have nevertheless been preserved; see
`obstructions/README.md` for their scope and additional dependencies.

## Upload and citation

Upload this directory's contents, including hidden files, as the repository
root. No `.git` directory, credentials, unrelated downloads, or local cache
are included. The supplied GitHub URL is included in the manuscript and `CITATION.cff`.
After publishing a tagged release or archival DOI, add that immutable identifier
to the citation metadata; none is invented here. Choose the desired code/data license before publication;
this bundle does not impose a new license on the preserved source material.

## Article source and arXiv upload

The current source is `paper/main.tex`, with `paper/reproducibility.tex`,
`paper/tables/excluded-candidates.tex` and both assets in `paper/figures/`.
The separate arXiv source ZIP contains those typesetting inputs at its root;
the GitHub package also retains the computational data and the two curve plate
sets. Read `paper/BUILD.md` for build instructions and the review status.
Queries stay in the side margins. Remaining proof obligations are explicit;
a successful build and the finite replays do not close them.
